export enum ValidSortParams {
  CREATED_AT = 'created_at',
  NAME = 'name',
  UPDATED_AT = 'updated_at',
}
