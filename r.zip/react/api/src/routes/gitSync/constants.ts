export const Provider = {
  github: 'github',
  gitlab: 'gitlab',
  local: 'local',
} as const;
