module.exports = /lang-\w\w(_\w\w){0,1}(\/)*/i;
