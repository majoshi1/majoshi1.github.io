export enum WebhookAction {
  LOGIN = 'login',
}
