export default function obfuscateKey(text: string, conceal = 'after', displayLength = 5) {
  if (!text) return '';

  const obfuscatedText =
    conceal === 'before' ? `••••••${text.substr(displayLength * -1)}` : `${text.slice(0, displayLength)}••••••`;

  return obfuscatedText;
}
