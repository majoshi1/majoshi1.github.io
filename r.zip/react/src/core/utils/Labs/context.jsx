import { createContext } from 'react';

const LabsContext = createContext({});
LabsContext.displayName = 'LabsContext';

export default LabsContext;
