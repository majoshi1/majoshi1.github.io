import type { SuperHubStore } from '..';
import type { StateCreator } from 'zustand';

import { actionLog } from '@core/store/util';

interface SuperHubEditorSliceState {
  /**
   * Indicates whether we are currently attempting to create a new page.
   */
  isCreateNewPage: boolean;

  /**
   * Indicates whether we are currently editing a "raw" markdown or using
   * the MarkdownEditor component UI.
   */
  isRawMode: boolean;

  /**
   * Indicates whether we are currently editing "realtime" pages on the
   * Developer Dashboard. These would be pages like
   * `/reference/intro/getting-started` or `/reference/intro/authentication`.
   */
  isRealTime: boolean;

  /**
   * After receiving an MdxValidationError, this flag is set to true to disable
   * the saving of the document.
   */
  isSavingDisabled: boolean;
}

interface SuperHubEditorSliceAction {
  /**
   * Re-enables saving the document after an MDX validation error, once the
   * editor has had a change.
   */
  reenableSaving: () => void;

  /**
   * Sets the isRawMode state.
   */
  updateRawMode: (isRawMode: boolean) => void;
}

export interface SuperHubEditorSlice {
  /**
   * State slice containing fields and actions that are relevant when editing
   * doc pages in SuperHub. This slice includes data about the page document
   * (body, excerpt, metadata, slug, etc) in addition to sidebar nav data.
   */
  editor: SuperHubEditorSliceAction & SuperHubEditorSliceState;
}

const initialState: SuperHubEditorSliceState = {
  isCreateNewPage: false,
  isRawMode: false,
  isRealTime: false,
  isSavingDisabled: false,
};

/**
 * SuperHubEditor state slice containing fields related to editing doc pages.
 */
export const createSuperHubEditorSlice: StateCreator<
  SuperHubEditorSlice & SuperHubStore,
  [['zustand/devtools', never], ['zustand/immer', never]],
  [],
  SuperHubEditorSlice
> = (set, get) => ({
  editor: {
    ...initialState,

    reenableSaving: () => {
      if (!get().editor.isSavingDisabled) return;

      set(
        state => {
          state.editor.isSavingDisabled = false;
        },
        false,
        actionLog('document.reenableSaving'),
      );
    },

    updateRawMode: isRawMode => {
      set(
        state => {
          state.editor.isRawMode = isRawMode;
        },
        false,
        actionLog('editor.updateRawMode', isRawMode),
      );
    },
  },
});
