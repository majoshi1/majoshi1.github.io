import type {
  ReadVersionCollectionType,
  CreateVersionType,
  ReadVersionType,
} from '@readme/api/src/mappings/version/types';

import { superHubStore } from '..';

/** Global counter to ensure factory-made versions stay unique. */
let mockVersionCount = 0;

/**
 * Returns a mock version that can be used for testing.
 */
export function mockVersion<Keys extends CreateVersionType>(keys: Partial<Keys> = {}) {
  mockVersionCount += 1;
  const defaultVersion = superHubStore.getState().versions.defaultVersion;
  const name = keys.name || `${mockVersionCount}.0`;
  return {
    base: '1.0',
    display_name: '',
    git: {
      latest_commit: { created_at: null, hash: null },
      branch_ref: null,
    },
    name,
    privacy: { view: defaultVersion === name ? 'default' : 'hidden' },
    release_stage: 'release',
    state: 'current',
    updated_at: new Date().toISOString(),
    uri: `/versions/${name}`,
    ...keys,
  } satisfies ReadVersionType['data'];
}

/**
 * Returns a mock collection of versions that can be used for testing. Generates
 * `n` number of mock versions based on the count provided.
 */
export function mockVersions(count: number): ReadVersionCollectionType {
  const versions = new Array(count).fill(null).map(() => mockVersion());
  return {
    data: versions,
    per_page: versions.length,
    total: versions.length,
    paging: {
      next: null,
      previous: null,
      first: null,
      last: null,
    },
    page: 1,
  };
}
