import { useContext, useEffect } from 'react';

import { ConfigContext, ProjectContext, UserContext } from '@core/context';

import useUniqueId from '../useUniqueId';

const useWootric = () => {
  // Small note that might matter in the future, but thought I’d document now so I don’t hate myself later:
  // In the dash `createdAt` is the date the user is created, but in the hub it’s the date the user first logs into their hub
  const { createdAt, isGod, user } = useContext(UserContext);
  const { project } = useContext(ProjectContext);
  const uid = useUniqueId('useWootric');
  const {
    wootric: { enabled, accountToken },
  } = useContext(ConfigContext);

  useEffect(() => {
    if (enabled) {
      window.wootricSettings = {
        account_token: accountToken,
        aria: true,
        created_at: Math.floor(new Date(createdAt).getTime() / 1000),
        email: user?.email || 'anonymous',
        scale_color: 'gradient',
        properties: {
          name: user?.name,
          plan: project?.plan,
          subdomain: project?.subdomain,
          superhub: project?.flags?.superHub,
        },
      };

      // Beacon
      const beacon = document.createElement('script');
      beacon.type = 'text/javascript';
      beacon.id = uid('wootric-beacon');
      beacon.async = true;
      beacon.src = 'https://cdn.wootric.com/wootric-sdk.js';
      beacon.onload = () => window.wootric('run');

      if (!document.getElementById('wootric-beacon')) {
        document.body.appendChild(beacon);
      }
    }
  }, [accountToken, createdAt, enabled, isGod, project, uid, user]);
};

export default useWootric;
