export const rdmdOpts = {
  safeMode: true,
};
