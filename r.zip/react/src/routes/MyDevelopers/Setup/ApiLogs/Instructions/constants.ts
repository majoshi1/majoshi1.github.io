export const PythonPackages = {
  Django: 'Django',
  Flask: 'Flask',
  WSGI: 'WSGI',
};
