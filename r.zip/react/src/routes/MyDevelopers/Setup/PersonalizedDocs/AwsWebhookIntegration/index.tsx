import type useSaveWebhook from '../useSaveWebhook';

import React from 'react';

import useClassy from '@core/hooks/useClassy';

import SetupAWSPersonalizationForm from '@routes/MyDevelopers/Setup/PersonalizedDocs/SetupAWSPersonalizationForm';

import Accordion, { AccordionPanel, AccordionToggle } from '@ui/Accordion';

import { WebhookManualInstructions } from '../WebhookInstructions';

import styles from './style.module.scss';

type UseSaveWebhookArgs = Parameters<typeof useSaveWebhook>;

interface AwsWebhookIntegrationProps {
  onSaveWebhook: UseSaveWebhookArgs[1];
}

export default function AwsWebhookIntegration({ onSaveWebhook }: AwsWebhookIntegrationProps) {
  const bem = useClassy(styles, 'AwsWebhookIntegration');

  return (
    <Accordion headingLevel={2}>
      <AccordionPanel initiallyOpen>
        <AccordionToggle>
          <div className={bem('-toggle-content')}>
            <span className={bem('-title')}>Option 1: ReadMe Managed</span>
            <p className={bem('-subtitle')}>Let us manage AWS Gateway API keys for you</p>
          </div>
        </AccordionToggle>
        <SetupAWSPersonalizationForm onSaveWebhook={onSaveWebhook} />
      </AccordionPanel>
      <AccordionPanel>
        <AccordionToggle>
          <div className={bem('-toggle-content')}>
            <span className={bem('-title')}>Option 2: Custom setup</span>
            <p className={bem('-subtitle')}>Manage your own API keys</p>
          </div>
        </AccordionToggle>
        <WebhookManualInstructions onSaveWebhook={onSaveWebhook} />
      </AccordionPanel>
    </Accordion>
  );
}
