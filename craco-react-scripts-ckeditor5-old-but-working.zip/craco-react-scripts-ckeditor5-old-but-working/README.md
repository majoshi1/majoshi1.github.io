# React ckeditor5

Run `npm run start` to start the app locally.
Run `npm run build` to build the app.
