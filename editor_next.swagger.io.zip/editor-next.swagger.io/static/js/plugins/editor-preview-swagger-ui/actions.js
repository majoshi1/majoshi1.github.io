export const EDITOR_PREVIEW_SWAGGER_UI_PREVIEW_UNMOUNTED =
    'editor_preview_swagger_ui_preview_unmounted';

export const previewUnmounted = () => ({
    type: EDITOR_PREVIEW_SWAGGER_UI_PREVIEW_UNMOUNTED,
});