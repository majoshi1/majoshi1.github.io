const DropdownMenuItemDivider = () => <li role="separator" />;

export default DropdownMenuItemDivider;
