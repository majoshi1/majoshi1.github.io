import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-login',
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class LoginComponent implements OnInit {
 

 
  
   isclicked : boolean= false;
  constructor(){  

   }
  ngOnInit()  {
   

  }
    


  login(){
  
 

  }


   
 
   
}

