Your pull request **can't** be merged due to missing the **Apache license** statement.

Please add the following statement at the end of the pr description:

`I submit this contribution under the Apache-2.0 license.` 

In case the statement has already been added, make sure it is the last sentence in the description and the only one in its line.

Thank you!
*KICS Team*