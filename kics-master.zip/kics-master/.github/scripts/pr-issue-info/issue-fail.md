Please, follow the guideline for an issue title: 

For **bug**:

`bug(<scope>): <title starting with lowercase letter>`

For **query**:

`query(<platform>): <title starting with lowercase letter>`

For **feature request**:

`feat(<scope>): <title starting with lowercase letter>`

Thank you!
*KICS Team*