Please, follow the guideline for a pull request title: 

`<type>(<scope>): <title starting with lowercase letter>`

You can read more about it [here](https://docs.kics.io/latest/CONTRIBUTING/#pull_requests).

Thank you!
*KICS Team*