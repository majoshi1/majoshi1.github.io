---
name: Query
about: Template to help create/update a query
title: 'query(<platform>): <title starting with lowercase letter>'
labels: community, query
assignees: ''

---

### Platform
*(e.g. Terraform, Ansible, etc.)*

### Provider
*(e.g. AWS, Azure, GCP, etc.)*

### Description
*Give a short description about the query*
