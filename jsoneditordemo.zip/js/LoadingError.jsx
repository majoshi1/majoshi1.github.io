import { faExclamationTriangle, faFile, faQuestionCircle } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React, { useState } from 'react'
import './LoadingError.scss'

export default function LoadingError({ error, onNew }) {
  const [showReasons, setShowReasons] = useState(false)

  function handleReadMore() {
    setShowReasons(true)
  }

  return (
    <div className="loading-error">
      <FontAwesomeIcon icon={faExclamationTriangle} /> {error.toString()}
      {error.reasons && showReasons && (
        <div className="reasons">
          <br />
          Possible reasons:
          <ul>
            {error.reasons.map((reason, index) => (
              <li key={index}>{reason}</li>
            ))}
          </ul>
        </div>
      )}
      <div className="suggestion">
        <button className="action primary" onClick={onNew}>
          <FontAwesomeIcon icon={faFile} /> Open a new document
        </button>
        {error.reasons && !showReasons && (
          <button className="action" onClick={handleReadMore}>
            <FontAwesomeIcon icon={faQuestionCircle} /> Read more
          </button>
        )}
      </div>
    </div>
  )
}
