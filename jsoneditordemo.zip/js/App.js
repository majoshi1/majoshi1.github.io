import { faChevronLeft, faChevronRight, faEllipsisV } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import classnames from 'classnames'
import createDebug from 'debug'
import { isEqual } from 'lodash'
import React, { Suspense, useEffect, useRef, useState } from 'react'
import { isEqualParser, isLargeContent, isTextContent } from 'svelte-jsoneditor' // do not use vanilla-jsoneditor to allow code splitting
import Ads from './Ads'
import './App.scss'
import {
  Formatting,
  LARGE_DOCUMENT_SIZE,
  LEFT_PANEL_ID,
  RIGHT_PANEL_ID,
  THEME,
  THEME_COLOR,
  THEME_COLOR_CLASSNAME,
  TRANSFORM_LEFT_TO_RIGHT_ID,
  TRANSFORM_RIGHT_TO_LEFT_ID
} from './constants'
import DocumentProvider from './DocumentProvider'
import useLocalStorage from './hooks/useLocalStorage'
import useSplitter from './hooks/useSplitter'
import Menu from './Menu'
import notify from './modal/notify'
import PanelActions from './PanelActions.js'
import { calculateDiffWithMaps, CREATE, DELETE, UPDATE } from './utils/calculateDiff'
import { parseContent, toSafeContent, tryFormat } from './utils/documentUtils'
import { loadFromLocalStorage, saveToLocalStorage } from './utils/localStorageUtils'
import { memoizeLastArguments } from './utils/memoizationUtils'
import useSystemTheme from './hooks/useSystemTheme'
import { isValidFontSize } from './utils/fontUtils'
import Donate from './Donate'
import JSONEditorPanelPlaceholder from './JSONEditorPanelPlaceholder'
import ErrorBoundary from './ErrorBoundary'
import DidYouKnow from './DidYouKnow'

const JSONEditorPanel = React.lazy(async () => import('./JSONEditorPanel'))

const BLINK_TIMEOUT = 1200 // ms, must be a multiple of the duration of one blink (0.3s)
const MIN_SPLITTER_VALUE = 0.15 // percentage
const JUMP_TO_SPLITTER_VALUE = 0.2 // percentage
const LAST_HASH_KEY = 'lastHash'

const debug = createDebug('jsoneditoronline:App')

/**
 * @param {Content} leftContent
 * @param {JSONParser} leftParser
 * @param {Content} rightContent
 * @param {JSONParser} rightParser
 * @return {{
 *   diffLeft: DiffMap,
 *   diffRight: DiffMap,
 *   changes: DiffAction[],
 *   error?: Error
 * }}
 */
const memoizedCalculateDiffWithMaps = memoizeLastArguments(function (
  leftContent,
  leftParser,
  rightContent,
  rightParser
) {
  try {
    // note that parseContent can throw an exception when the content is text containing invalid JSON
    const left = parseContent(leftContent, leftParser)
    const right = parseContent(rightContent, rightParser)

    const start = Date.now()
    const diff = calculateDiffWithMaps(left, right)
    const end = Date.now()

    debug(`Calculated diff in ${end - start} milliseconds`, diff)

    return diff
  } catch (error) {
    return {
      changes: [],
      diffLeft: {},
      diffRight: {},
      error
    }
  }
})

// FIXME: loading lastHash here instead of inside App is a hotfix to prevent
//  it from being reset already on page load
const lastHash = loadFromLocalStorage(LAST_HASH_KEY, '')
const currentHash = window.location.hash
if (currentHash === '' && lastHash !== '') {
  debug('load lastHash', { lastHash })
  window.location.hash = lastHash
}

export default function App() {
  const [indentation, setIndentation] = useLocalStorage('indentation', 2)
  const [tabSize, setTabSize] = useLocalStorage('tabSize', 4)
  const [escapeControlCharacters, setEscapeControlCharacters] = useLocalStorage(
    'escapeControlCharacters',
    false
  )
  const [escapeUnicodeCharacters, setEscapeUnicodeCharacters] = useLocalStorage(
    'escapeUnicodeCharacters',
    false
  )
  const [flattenColumns, setFlattenColumns] = useLocalStorage('setFlattenColumns', true)
  const [parserId, setParserId] = useLocalStorage('parserId', 'lossless')
  const [queryLanguageId, onChangeQueryLanguage] = useLocalStorage('queryLanguageId', 'lodash')
  const [leftMode, setLeftMode] = useLocalStorage('leftMode', 'text')
  const [rightMode, setRightMode] = useLocalStorage('rightMode', 'tree')
  const systemTheme = useSystemTheme()
  const [theme, setTheme] = useLocalStorage('theme', 'auto')
  const [themeColor, setThemeColor] = useLocalStorage('theme-color', 'default')
  const [fontSize, setFontSize] = useLocalStorage('fontSize', '14px')
  const [splitterValue, setSplitterValue] = useLocalStorage('splitterValue', 0.5)
  const [formattingOnSave, setFormattingOnSave] = useLocalStorage(
    'formattingOnSave',
    Formatting.KEEP
  )
  const [focusLeft, setFocusLeft] = useState(false)
  const [focusRight, setFocusRight] = useState(false)
  const [showDiff, setShowDiff] = useLocalStorage('showDiff', false)
  const [selectedDiffChange, setSelectedDiffChange] = useState(null)
  const [leftEditorRef, setLeftEditorRef] = useState(null)
  const [rightEditorRef, setRightEditorRef] = useState(null)

  const isDarkTheme = (theme === THEME.AUTO && systemTheme === THEME.DARK) || theme === THEME.DARK
  const themeClass = isDarkTheme ? 'jse-theme-dark' : 'jse-theme-light'

  useEffect(() => {
    document.body.classList.toggle('jse-theme-light', !isDarkTheme)
    document.body.classList.toggle('jse-theme-dark', isDarkTheme)
  }, [themeClass])

  const themeColorClass = THEME_COLOR_CLASSNAME[themeColor]

  useEffect(() => {
    document.body.classList.toggle(
      THEME_COLOR_CLASSNAME[THEME_COLOR.GREEN],
      THEME_COLOR_CLASSNAME[THEME_COLOR.GREEN] === themeColorClass
    )
    document.body.classList.toggle(
      THEME_COLOR_CLASSNAME[THEME_COLOR.BLUE],
      THEME_COLOR_CLASSNAME[THEME_COLOR.BLUE] === themeColorClass
    )
    document.body.classList.toggle(
      THEME_COLOR_CLASSNAME[THEME_COLOR.RED],
      THEME_COLOR_CLASSNAME[THEME_COLOR.RED] === themeColorClass
    )
  }, [themeColorClass])

  useEffect(() => {
    debug(`change font-size to ${fontSize}`)

    if (!isValidFontSize(fontSize)) {
      console.warn(`Cannot apply font-size: invalid font size "${fontSize}"`)
      return
    }

    const root = document.documentElement
    if (!root) {
      console.warn('Cannot apply font-size: no root found')
      return
    }

    root.style.setProperty('--jse-font-size-mono', fontSize)

    if (leftMode === 'text' && leftEditorRef) {
      leftEditorRef.refresh()
    }
    if (rightMode === 'text' && rightEditorRef) {
      rightEditorRef.refresh()
    }
  }, [fontSize])

  // automatically load last opened documents
  useEffect(() => {
    function updateLastHash() {
      const lastHash = window.location.hash
      debug('save lastHash', { lastHash })
      saveToLocalStorage(LAST_HASH_KEY, lastHash)
    }

    window.addEventListener('hashchange', updateLastHash)
    return function () {
      window.removeEventListener('hashchange', updateLastHash)
    }
  }, [])

  useEffect(() => {
    if (window.location.protocol === 'http:' && window.location.hostname !== 'localhost') {
      notify({
        text: (
          <>
            You&apos;re using an unsecured url (http). Please switch to the secure url{' '}
            <a href="https://jsoneditoronline.org">https://jsoneditoronline.org</a> and update any
            bookmarks. <a href="/changelog.html#2022-07-04-version-634">Read more</a>.
          </>
        ),
        closable: true
      })
    }
  }, [])

  const refContainer = useRef(null)
  const refSplitter = useRef(null)
  useSplitter({ setSplitterValue, refContainer, refSplitter })

  const renderLeftPanel = splitterValue >= MIN_SPLITTER_VALUE
  const renderRightPanel = splitterValue <= 1 - MIN_SPLITTER_VALUE
  const renderBothPanels = renderLeftPanel && renderRightPanel
  const splitterIcon = !renderLeftPanel
    ? faChevronRight
    : !renderRightPanel
    ? faChevronLeft
    : faEllipsisV

  function handleClickSplitter() {
    if (!renderLeftPanel) {
      setSplitterValue(JUMP_TO_SPLITTER_VALUE)
    }
    if (!renderRightPanel) {
      setSplitterValue(1 - JUMP_TO_SPLITTER_VALUE)
    }
  }

  return (
    <div className="app">
      <Menu
        theme={theme}
        setTheme={setTheme}
        themeColor={themeColor}
        setThemeColor={setThemeColor}
      />
      <DocumentProvider
        hashKey="left"
        indentation={indentation}
        parserId={parserId}
        loadDefaultDocumentOnFirstUse
      >
        {(leftDocumentProps) => {
          return (
            <DocumentProvider hashKey="right" indentation={indentation} parserId={parserId}>
              {(rightDocumentProps) => {
                const allPanels = [
                  {
                    panelId: LEFT_PANEL_ID,
                    compoundKey: leftDocumentProps.compoundKey,
                    document: leftDocumentProps.document
                  },
                  {
                    panelId: RIGHT_PANEL_ID,
                    compoundKey: rightDocumentProps.compoundKey,
                    document: rightDocumentProps.document
                  }
                ]

                function ensureSafeContent(content, sourceParser, destinyParser) {
                  return !isEqualParser(sourceParser, destinyParser) && destinyParser === JSON
                    ? toSafeContent(content, sourceParser, indentation)
                    : content
                }

                function ensureSafeContentAndTryFormat(content, sourceParser, destinyParser) {
                  const formattedContent = isTextContent(content)
                    ? { text: tryFormat(content.text, sourceParser, indentation) }
                    : content

                  return ensureSafeContent(formattedContent, sourceParser, destinyParser)
                }

                async function copyLeftToRight() {
                  await rightDocumentProps.updateDocumentProperties({
                    content: ensureSafeContentAndTryFormat(
                      leftDocumentProps.document.content,
                      leftDocumentProps.parser,
                      rightDocumentProps.parser
                    )
                  })
                }

                async function copyRightToLeft() {
                  await leftDocumentProps.updateDocumentProperties({
                    content: ensureSafeContentAndTryFormat(
                      rightDocumentProps.document.content,
                      rightDocumentProps.parser,
                      leftDocumentProps.parser
                    )
                  })
                }

                async function applyIndentation(newIndentation) {
                  if (newIndentation === indentation) {
                    return
                  }

                  setIndentation(newIndentation)

                  await tryApplyIndentation(leftDocumentProps)
                  await tryApplyIndentation(rightDocumentProps)

                  async function tryApplyIndentation(documentProps) {
                    const content = documentProps.document.content
                    if (isTextContent(content)) {
                      await documentProps.updateDocumentProperties({
                        content: {
                          text: tryFormat(content.text, documentProps.parser, indentation)
                        }
                      })
                    }
                  }
                }

                function transformLeftToRight() {
                  leftEditorRef.transform({
                    id: TRANSFORM_LEFT_TO_RIGHT_ID,
                    onTransform: async ({ transformedJson }) => {
                      debug('transform left to right')

                      const content = {
                        json: transformedJson
                      }

                      await rightDocumentProps.updateDocumentProperties({
                        content: ensureSafeContent(
                          content,
                          leftDocumentProps.parser,
                          rightDocumentProps.parser
                        )
                      })
                    },
                    onClose: () => {
                      // the setTimeout is to make it work when the other panel has text mode open
                      setTimeout(() => rightEditorRef.focus())
                    }
                  })
                }

                function transformRightToLeft() {
                  rightEditorRef.transform({
                    id: TRANSFORM_RIGHT_TO_LEFT_ID,
                    onTransform: async ({ transformedJson }) => {
                      debug('transform left to right')

                      const content = {
                        json: transformedJson
                      }

                      await leftDocumentProps.updateDocumentProperties({
                        content: ensureSafeContent(
                          content,
                          rightDocumentProps.parser,
                          leftDocumentProps.parser
                        )
                      })
                    },
                    onClose: () => {
                      // the setTimeout is to make it work when the other panel has text mode open
                      setTimeout(() => leftEditorRef.focus())
                    }
                  })
                }

                function toggleDiff() {
                  if (showDiff) {
                    setShowDiff(false)
                  } else {
                    setShowDiff(true)
                    setSelectedDiffChange(null) // reset when enabling diff
                    if (leftMode !== 'tree' || rightMode !== 'tree') {
                      const notification = notify({
                        text: (
                          <>
                            Highlighting of differences between left and right panel is only
                            available in tree mode.{' '}
                            <button
                              className="action"
                              onClick={(event) => {
                                event.preventDefault()
                                setLeftMode('tree')
                                setRightMode('tree')
                                notification.close()
                              }}
                            >
                              Switch to tree mode
                            </button>
                          </>
                        ),
                        closable: true,
                        className: 'wide'
                      })
                    }
                  }
                }
                function tryCalculateDiff() {
                  if (!showDiff) {
                    return undefined
                  }

                  const tooLarge =
                    isLargeContent(leftDocumentProps.document.content, LARGE_DOCUMENT_SIZE) ||
                    isLargeContent(rightDocumentProps.document.content, LARGE_DOCUMENT_SIZE)

                  if (tooLarge) {
                    setShowDiff(false)

                    notify({
                      text: 'Diff calculation is turned off: documents are too large.',
                      closable: true,
                      timeout: 60000
                    })

                    return undefined
                  }

                  return showDiff && !tooLarge
                    ? memoizedCalculateDiffWithMaps(
                        leftDocumentProps.document.content,
                        leftDocumentProps.parser,
                        rightDocumentProps.document.content,
                        rightDocumentProps.parser
                      )
                    : undefined
                }

                const diff = tryCalculateDiff()
                const diffChangeIndex = findChangeIndex(selectedDiffChange)
                const diffChangeCount = diff && diff.changes ? diff.changes.length : undefined

                function toPreviousDiff() {
                  const changes = diff.changes
                  if (!changes) {
                    return
                  }

                  const previousIndex = diffChangeIndex > 0 ? diffChangeIndex - 1 : 0
                  const action = changes[previousIndex]

                  if (action) {
                    scrollToDiffChange(action)
                  }
                }

                function toNextDiff() {
                  const changes = diff.changes
                  if (!changes) {
                    return
                  }

                  const nextIndex =
                    diffChangeIndex < changes.length - 1 ? diffChangeIndex + 1 : changes.length - 1

                  const action = changes[nextIndex]

                  if (action) {
                    scrollToDiffChange(action)
                  }
                }

                function findChangeIndex(selectedChange) {
                  if (!selectedChange || !diff || !diff.changes) {
                    return -1
                  }

                  // first try an exact match
                  const index = diff.changes.findIndex((change) => isEqual(change, selectedChange))
                  if (index !== -1) {
                    return index
                  }

                  // if not found, try a less exact match, matching one of the two paths
                  // this way we can often keep track on the index whilst changes have been made in the document
                  return diff.changes.findIndex((change) => {
                    return (
                      isEqual(change.pathLeft, selectedChange.pathLeft) ||
                      isEqual(change.pathRight, selectedChange.pathRight)
                    )
                  })
                }

                function scrollToDiffChange(diffChange) {
                  const path =
                    diffChange && Array.isArray(diffChange.pathLeft)
                      ? diffChange.pathLeft
                      : diffChange.pathRight

                  setSelectedDiffChange(diffChange)
                  debug('scrollTo', path, {
                    changes: diff.changes,
                    path,
                    leftEditorRef,
                    rightEditorRef
                  })

                  if (
                    leftEditorRef &&
                    (diffChange.change === DELETE || diffChange.change === UPDATE)
                  ) {
                    leftEditorRef.scrollTo(diffChange.pathLeft).then(() => {
                      const element = leftEditorRef.findElement(diffChange.pathLeft)
                      if (element) {
                        blinkElement(element)
                      }

                      debug('left panel: scroll to node', { element, path: diffChange.pathLeft })
                    })
                  }

                  if (
                    rightEditorRef &&
                    (diffChange.change === CREATE || diffChange.change === UPDATE)
                  ) {
                    rightEditorRef.scrollTo(diffChange.pathRight).then(() => {
                      const element = rightEditorRef.findElement(diffChange.pathRight)
                      if (element) {
                        blinkElement(element)
                      }
                      debug('right panel: scroll to node', { element, path: diffChange.pathRight })
                    })
                  }
                }

                // TODO: move function blinkElement into a DOM utils file
                function blinkElement(element) {
                  setTimeout(() => element.classList.add('blink-diff-value'))
                  setTimeout(() => element.classList.remove('blink-diff-value'), BLINK_TIMEOUT)
                }

                function closeDocumentInAllPanels(compoundKey) {
                  const allDocumentProps = [leftDocumentProps, rightDocumentProps]

                  allDocumentProps
                    .filter((documentProps) => documentProps.compoundKey === compoundKey)
                    .forEach((documentProps) => {
                      debug('close document', documentProps)
                      documentProps.loadDocument(null)
                    })
                }

                // TODO: cleanup or reuse. This is disabled since 2022-10-14 to see if it improves ranking in Google
                //  having only a single page title in Google Analytics
                // // FIXME: create a hook useDocumentTitle (after refactoring DocumentProvider into a hook)
                // window.document.title = getDocumentTitle(
                //   leftDocumentProps.document.name,
                //   rightDocumentProps.document.name
                // )

                return (
                  <div className="body">
                    <div ref={refContainer} className="contents-panel">
                      {renderLeftPanel && (
                        <div
                          className={classnames('left-panel', { focus: focusLeft })}
                          style={{ flex: renderBothPanels ? splitterValue : 1 }}
                        >
                          <ErrorBoundary>
                            <Suspense fallback={<JSONEditorPanelPlaceholder mode={leftMode} />}>
                              <JSONEditorPanel
                                key={leftDocumentProps.documentSequenceNr}
                                panelId={LEFT_PANEL_ID}
                                jsonEditorRef={leftEditorRef}
                                setJsonEditorRef={setLeftEditorRef}
                                focus={focusLeft}
                                setFocus={setFocusLeft}
                                mode={leftMode}
                                setMode={setLeftMode}
                                indentation={indentation}
                                setIndentation={applyIndentation}
                                parserId={parserId}
                                setParserId={setParserId}
                                tabSize={tabSize}
                                setTabSize={setTabSize}
                                fontSize={fontSize}
                                setFontSize={setFontSize}
                                formattingOnSave={formattingOnSave}
                                setFormattingOnSave={setFormattingOnSave}
                                escapeControlCharacters={escapeControlCharacters}
                                setEscapeControlCharacters={setEscapeControlCharacters}
                                escapeUnicodeCharacters={escapeUnicodeCharacters}
                                setEscapeUnicodeCharacters={setEscapeUnicodeCharacters}
                                flattenColumns={flattenColumns}
                                setFlattenColumns={setFlattenColumns}
                                queryLanguageId={queryLanguageId}
                                onChangeQueryLanguage={onChangeQueryLanguage}
                                allPanels={allPanels}
                                closeAndDeleteDocument={async (compoundKey) => {
                                  closeDocumentInAllPanels(compoundKey)
                                  await leftDocumentProps.deleteDocument(compoundKey)
                                }}
                                {...leftDocumentProps}
                                diff={diff && diff.diffLeft}
                              />
                            </Suspense>
                          </ErrorBoundary>
                        </div>
                      )}
                      <div className="center-panel">
                        {renderBothPanels && (
                          <>
                            <div className="empty-space-top" />
                            <PanelActions
                              copyLeftToRight={copyLeftToRight}
                              copyRightToLeft={copyRightToLeft}
                              transformLeftToRight={transformLeftToRight}
                              transformRightToLeft={transformRightToLeft}
                              toggleDiff={toggleDiff}
                              showDiff={showDiff}
                              diff={diff}
                              diffChangeCount={diffChangeCount}
                              diffChangeIndex={diffChangeIndex}
                              toPreviousDiff={toPreviousDiff}
                              toNextDiff={toNextDiff}
                            />
                          </>
                        )}
                        <div
                          ref={refSplitter}
                          onClick={handleClickSplitter}
                          className="draggable-splitter"
                          title="Drag left or right to change the width of the panels"
                        >
                          <div className="draggable-splitter-icon">
                            <FontAwesomeIcon icon={splitterIcon} fixedWidth />
                          </div>
                        </div>
                      </div>
                      {renderRightPanel && (
                        <div
                          className={classnames('right-panel', { focus: focusRight })}
                          style={{ flex: renderBothPanels ? 1 - splitterValue : 1 }}
                        >
                          <ErrorBoundary>
                            <Suspense fallback={<JSONEditorPanelPlaceholder mode={rightMode} />}>
                              <JSONEditorPanel
                                key={rightDocumentProps.documentSequenceNr}
                                panelId={RIGHT_PANEL_ID}
                                jsonEditorRef={rightEditorRef}
                                setJsonEditorRef={setRightEditorRef}
                                focus={focusRight}
                                setFocus={setFocusRight}
                                mode={rightMode}
                                setMode={setRightMode}
                                indentation={indentation}
                                setIndentation={applyIndentation}
                                parserId={parserId}
                                setParserId={setParserId}
                                tabSize={tabSize}
                                setTabSize={setTabSize}
                                fontSize={fontSize}
                                setFontSize={setFontSize}
                                formattingOnSave={formattingOnSave}
                                setFormattingOnSave={setFormattingOnSave}
                                escapeControlCharacters={escapeControlCharacters}
                                setEscapeControlCharacters={setEscapeControlCharacters}
                                escapeUnicodeCharacters={escapeUnicodeCharacters}
                                setEscapeUnicodeCharacters={setEscapeUnicodeCharacters}
                                flattenColumns={flattenColumns}
                                setFlattenColumns={setFlattenColumns}
                                queryLanguageId={queryLanguageId}
                                onChangeQueryLanguage={onChangeQueryLanguage}
                                allPanels={allPanels}
                                closeAndDeleteDocument={async (compoundKey) => {
                                  closeDocumentInAllPanels(compoundKey)
                                  await rightDocumentProps.deleteDocument(compoundKey)
                                }}
                                {...rightDocumentProps}
                                diff={diff && diff.diffRight}
                              />
                            </Suspense>
                          </ErrorBoundary>
                        </div>
                      )}
                    </div>
                    <div className="ad-panel">
                      <Ads />
                      <Donate />
                      <DidYouKnow />
                    </div>
                  </div>
                )
              }}
            </DocumentProvider>
          )
        }}
      </DocumentProvider>
    </div>
  )
}
