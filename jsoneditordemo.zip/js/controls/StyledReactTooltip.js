import ReactTooltip from 'react-tooltip'
import './StyledReactTooltip.scss'

export default function StyledReactTooltip(props) {
  return (
    <ReactTooltip
      effect="solid"
      className="jeo-react-tooltip"
      backgroundColor="#4d4d4d"
      {...props}
    />
  )
}
