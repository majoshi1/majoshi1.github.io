import React from 'react'
import './Toggle.scss'
import classnames from 'classnames'

/**
 * @typedef {Object} ToggleOption
 * @property {*} value
 * @property {string} text
 * @property {string} [className]
 */

/**
 * @param {Object} props
 * @property {ToggleOption[]} options
 * @property {*} value
 * @property {function(schema: Schema)} onChange
 * @property {string} [className]
 * @return {React.FunctionComponent}
 */
export default function Toggle({ options, value, onChange, className }) {
  return (
    <div className={classnames('toggle', className)}>
      {options.map((option) => {
        const optionClassName = classnames({
          className: option.className,
          selected: option.value === value
        })

        return (
          <button
            key={String(option.value)}
            className={optionClassName}
            onClick={(event) => {
              event.preventDefault()
              onChange(option.value)
            }}
          >
            {option.text}
          </button>
        )
      })}
    </div>
  )
}
