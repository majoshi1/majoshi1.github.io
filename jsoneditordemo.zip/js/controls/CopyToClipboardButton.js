import { faCopy } from '@fortawesome/free-regular-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React, { useState } from 'react'
import CopyToClipboard from 'react-copy-to-clipboard'
import useTimeout from '../hooks/useTimeout'
import createDebug from 'debug'
import './CopyToClipboardButton.scss'

const debug = createDebug('jsoneditoronline:CopyToClipboardButton')

const COPIED_DURATION = 1000 // ms

export default function CopyToClipboardButton({ data, text, title, copiedText }) {
  const [copied, setCopied] = useState(false)
  const [setToggleTimeout] = useTimeout()

  function handleCopy() {
    debug('Text copied to clipboard', { data })
    setCopied(true)
    setToggleTimeout(() => setCopied(false), COPIED_DURATION)
  }

  return (
    <CopyToClipboard
      text={data}
      onCopy={handleCopy}
      className="modal-button primary copy-clipboard "
    >
      <div className="modal-button primary">
        <FontAwesomeIcon icon={faCopy} title={title} />
        {copied && copiedText ? ` ${copiedText}` : text ? ` ${text}` : undefined}
      </div>
    </CopyToClipboard>
  )
}
