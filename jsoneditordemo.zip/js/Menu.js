import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import classnames from 'classnames'
import React from 'react'
import {
  THEME,
  THEME_COLOR,
  THEME_COLOR_CLASSNAME,
  THEME_DESCRIPTION,
  THEME_ICONS
} from './constants'
import { createPortal } from 'react-dom'
import { faCaretDown, faCircle } from '@fortawesome/free-solid-svg-icons'
import './Menu.scss'

export default function Menu({ theme, setTheme, themeColor, setThemeColor }) {
  return createPortal(
    <div className="button static-dropdown-button theme-menu">
      <div
        className="static-dropdown-description"
        title={`Select a theme (Current theme: ${THEME_DESCRIPTION[theme]})`}
      >
        <FontAwesomeIcon icon={THEME_ICONS[theme]} /> Theme <FontAwesomeIcon icon={faCaretDown} />
      </div>
      <div className="static-dropdown-menu right">
        <div className="button-group-header">Theme</div>
        <button
          className={classnames('button dropdown-menu-button', { selected: theme === THEME.AUTO })}
          onClick={() => setTheme(THEME.AUTO)}
          title="Select the light or dark theme based on the default of your browser"
        >
          <FontAwesomeIcon icon={THEME_ICONS['auto']} fixedWidth /> {THEME_DESCRIPTION[THEME.AUTO]}
        </button>
        <button
          className={classnames('button dropdown-menu-button', { selected: theme === THEME.LIGHT })}
          onClick={() => setTheme(THEME.LIGHT)}
          title="Select the light theme"
        >
          <FontAwesomeIcon icon={THEME_ICONS[THEME.LIGHT]} fixedWidth />{' '}
          {THEME_DESCRIPTION[THEME.LIGHT]}
        </button>
        <button
          className={classnames('button dropdown-menu-button', { selected: theme === THEME.DARK })}
          onClick={() => setTheme(THEME.DARK)}
          title="Select the dark theme"
        >
          <FontAwesomeIcon icon={THEME_ICONS[THEME.DARK]} fixedWidth />{' '}
          {THEME_DESCRIPTION[THEME.DARK]}
        </button>

        <div className="button-group-header">Theme color</div>
        <button
          className={classnames(
            'button dropdown-menu-button',
            THEME_COLOR_CLASSNAME[THEME_COLOR.GREEN],
            {
              selected: themeColor === THEME_COLOR.GREEN
            }
          )}
          onClick={() => setThemeColor(THEME_COLOR.GREEN)}
          title="Select the green theme color"
        >
          <FontAwesomeIcon icon={faCircle} fixedWidth /> Green (default)
        </button>
        <button
          className={classnames(
            'button dropdown-menu-button',
            THEME_COLOR_CLASSNAME[THEME_COLOR.BLUE],
            {
              selected: themeColor === THEME_COLOR.BLUE
            }
          )}
          onClick={() => setThemeColor(THEME_COLOR.BLUE)}
          title="Select the red theme color"
        >
          <FontAwesomeIcon icon={faCircle} fixedWidth /> Blue
        </button>
        <button
          className={classnames(
            'button dropdown-menu-button',
            THEME_COLOR_CLASSNAME[THEME_COLOR.RED],
            {
              selected: themeColor === THEME_COLOR.RED
            }
          )}
          onClick={() => setThemeColor(THEME_COLOR.RED)}
          title="Select the red theme color"
        >
          <FontAwesomeIcon icon={faCircle} fixedWidth /> Red
        </button>
      </div>
    </div>,
    document.querySelector('#theme-toggle')
  )
}
