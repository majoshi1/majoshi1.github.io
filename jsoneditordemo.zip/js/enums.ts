export enum ParserId {
  'native' = 'native',
  'lossless' = 'lossless',
  'auto' = 'auto'
}
