import { faSave as faSaveRegular } from '@fortawesome/free-regular-svg-icons'
import {
  faCaretDown,
  faCheck,
  faCircleNotch,
  faCloud,
  faCog,
  faCopy,
  faEdit,
  faExclamationTriangle,
  faFile,
  faFolderOpen,
  faGear,
  faInfo,
  faLaptop,
  faLink,
  faSave,
  faShareAlt,
  faTable,
  faTimes
} from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import classnames from 'classnames'
import createDebug from 'debug'
import React, { useCallback, useEffect, useRef, useState } from 'react'
import { FileDrop } from 'react-file-drop'
import { Formatting, FORMATTING_OPTIONS } from './constants.js'
import useSchema from './hooks/useSchema'
import './JSONEditorPanel.scss'
import LoadingError from './LoadingError.jsx'
import confirm from './modal/confirm'
import documentPropertiesModal from './modal/documentPropertiesModal'
import openModal from './modal/openModal'
import prompt, { Prompt } from './modal/prompt'
import schemaModal from './modal/schema/schemaModal'
import shareModal from './modal/shareModal'
import { isCloudDocument, stringifyContent } from './utils/documentUtils'
import { notifyError, notifySuccess } from './utils/modalUtils.js'
import CSVExportModal from './modal/CSVExportModal'
import ConfigurationModal from './modal/ConfigurationModal'
import { fromProxyUrl, isProxyUrl, toProxyUrl } from './utils/proxyUrl'
import JSONEditorComponent from './JSONEditorComponent'
import useDimensions from 'react-cool-dimensions'
import StyledReactTooltip from './controls/StyledReactTooltip'

const debug = createDebug('jsoneditoronline:JSONEditorPanel')

const EMPTY_CONTENT = { json: '' }
const MENU_BUTTONS_TEXT_WIDTH = 499 // px
const MENU_BUTTONS_ICON_WIDTH = 255 // px
const UNSAVED_CHANGES_TEXT_WITH = 170 // px
const UNSAVED_CHANGES_ICON_WITH = 40 // px

export default function JSONEditorPanel({
  panelId,
  jsonEditorRef,
  setJsonEditorRef,
  mode,
  setMode,
  focus,
  setFocus,
  loading,
  error,
  localStorageError,
  unsavedChanges,
  document,
  compoundKey,
  diff,
  parser,
  indentation,
  setIndentation,
  parserId,
  setParserId,
  tabSize,
  setTabSize,
  fontSize,
  setFontSize,
  formattingOnSave,
  setFormattingOnSave,
  escapeControlCharacters,
  setEscapeControlCharacters,
  escapeUnicodeCharacters,
  setEscapeUnicodeCharacters,
  flattenColumns,
  setFlattenColumns,
  updateDocument,
  newDocument,
  updateDocumentProperties,
  renameDocument,
  loadDocument,
  loadFromDisk,
  loadFromUrl,
  saveToCloud,
  saveToDisk,
  saveToUrl,
  saveChanges,
  closeAndDeleteDocument,
  queryLanguageId,
  onChangeQueryLanguage,
  allPanels // for useSchema
}) {
  const [showCSVExportModal, setShowCSVExportModal] = useState(false)
  const [showConfigurationModal, setShowConfigurationModal] = useState(false)
  const [showOpenUrlPrompt, setShowOpenUrlPrompt] = useState(false)
  const refSelectFile = useRef(null)
  const jsonEditorRefCopy = useRef(null)
  const schema = useSchema(document.schema, panelId, allPanels)
  const { observe: observePanel, width: menuWidth } = useDimensions()
  const { observe: observeDocumentDetails, width: documentTitleWidth } = useDimensions()

  const content = document ? document.content : EMPTY_CONTENT

  const remainingWidth = menuWidth - documentTitleWidth
  const showButtonsText = remainingWidth - UNSAVED_CHANGES_ICON_WITH > MENU_BUTTONS_TEXT_WIDTH
  const showChangesText =
    remainingWidth - (showButtonsText ? MENU_BUTTONS_TEXT_WIDTH : MENU_BUTTONS_ICON_WIDTH) >
    UNSAVED_CHANGES_TEXT_WITH
  const wrapMenu = remainingWidth - UNSAVED_CHANGES_ICON_WITH - MENU_BUTTONS_ICON_WIDTH < 0
  const showChanges = unsavedChanges && !localStorageError

  const onNew = () => {
    newDocument()
  }

  const onRename = () => {
    prompt({
      title: 'Rename',
      text: 'Enter a new name for the document:',
      value: document.name || 'New document',
      onOk: renameDocument
    })
  }

  const onOpen = useCallback(async () => {
    openModal({
      onOpen: async (compoundKey) => {
        debug('onOpen', { compoundKey })
        await loadDocument(compoundKey)
      },
      onDelete: closeAndDeleteDocument
    })
  }, [loadDocument, closeAndDeleteDocument])

  const onSave = useCallback(async () => {
    await saveChanges({ force: true, silent: false })
  }, [saveChanges])

  const onSaveToCloud = useCallback(async () => {
    if (isCloudDocument(compoundKey)) {
      await saveToCloud()
    } else {
      // ask name first
      prompt({
        title: 'Save to cloud',
        text: 'Enter a name for the document:',
        value: document.name || 'New document',
        textOk: 'Save',
        onOk: async function (name) {
          await updateDocumentProperties({ name })
          await saveToCloud()
          applyFocus()
        }
      })
    }
  }, [compoundKey, document.name, updateDocumentProperties, saveToCloud])

  const onSaveToDisk = async () => {
    prompt({
      title: 'Save to disk',
      text: 'Enter a name for the document:',
      value: document.name || 'New document',
      optionText: 'Indentation',
      optionTitle: 'Select whether to format or compact the data before saving',
      optionValue: formattingOnSave,
      optionOptions: FORMATTING_OPTIONS,
      optionChange: setFormattingOnSave,
      textOk: 'Save',
      onOk: (name, formatting) => {
        // get out of "accept auto repair" mode, so we will copy repaired code in Tree mode
        jsonEditorRef.acceptAutoRepair()

        // wait until next tick so the data is actually repaired
        setTimeout(() => {
          saveToDisk(name, formatting)
          applyFocus()
        })
      }
    })
  }

  function onLoadFromUrl() {
    setShowOpenUrlPrompt(true)
  }

  const onSaveToUrl = async () => {
    prompt({
      className: 'save-url-prompt',
      title: 'Save to url',
      text: (
        <div>
          <p>Enter a public url of a server.</p>
          <p>
            When clicking Save, an HTTP POST request will be send to the selected url with the JSON
            document as body. The url must be secure (https), must not require authentication, and
            must have CORS enabled.
          </p>
        </div>
      ),
      value: document.savedToUrl || document.loadedFromUrl || '',
      optionText: 'Indentation',
      optionTitle: 'Select whether to format or compact the data before saving',
      optionValue: formattingOnSave,
      optionOptions: FORMATTING_OPTIONS,
      optionChange: setFormattingOnSave,
      textOk: 'Save',
      onOk: (name, formatting) => {
        // get out of "accept auto repair" mode, so we will copy repaired code in Tree mode
        jsonEditorRef.acceptAutoRepair()

        // wait until next tick so the data is actually repaired
        setTimeout(() => {
          saveToUrl(name, formatting)
          applyFocus()
        })
      }
    })
  }

  const onExportToCSV = () => {
    // TODO: open popup where you can specify options and a name, see a preview, and save to disk or copy to clipboard
    // TODO: implement modal option "header: boolean"
    // TODO: implement modal option "flatten: boolean"
    // debug('export to CSV', document)
    // const name = 'document.csv'
    // const options = {
    //   header: true
    // }
    // exportToCSV(name, options)

    setShowCSVExportModal(true)
  }

  /**
   * @param {FormattingOption} formatting
   */
  async function onCopy(formatting) {
    try {
      // get out of "accept auto repair" mode, so we will copy repaired code in Tree mode
      const updatedContent = jsonEditorRef.acceptAutoRepair()

      const clipboard = stringifyContent(updatedContent, parser, formatting, indentation)

      await navigator.clipboard.writeText(clipboard)

      applyFocus()

      notifySuccess('Document copied to clipboard')
    } catch (error) {
      // TODO: this is ugly code, refactor this
      if (formatting === Formatting.FORMAT || formatting === Formatting.COMPACT) {
        const message =
          `Failed to ${formatting} the document. ` +
          'Fix the document and click copy again, or use "Copy as-is". ' +
          error.toString()
        console.error(message)
        notifyError(message)
      } else {
        console.error(error)
        notifyError(error)
      }
    }
  }

  const onDeleteDocument = () => {
    confirm({
      title: 'Delete document',
      text: `Are you sure you want to delete document "${document.name}"?`,
      textOk: 'Delete',
      classOk: 'danger',
      onOk: () => {
        closeAndDeleteDocument(compoundKey)
      }
    })
  }

  const updateContent = useCallback(
    async function (content) {
      await updateDocument({ ...document, content })
    },
    [updateDocument, document]
  )

  const handleClassName = useCallback(
    (path) => {
      const key = path.length > 0 ? '/' + path.join('/') : ''
      const operation = diff[key]
      if (operation) {
        return `diff-${operation}`
      }
    },
    [diff]
  )

  function onSchema() {
    schemaModal({
      indentation,
      queryLanguageId,
      onChangeQueryLanguage,
      initialSchema: document.schema,
      panelId,
      allPanels,
      onOk: (schema) => {
        debug('Selected JSON Schema', schema)
        updateDocument({ ...document, schema }, /* saveImmediately = */ true)
      }
    })
  }

  const onDocumentProperties = useCallback(
    function () {
      documentPropertiesModal({ document, compoundKey })
    },
    [document, compoundKey]
  )

  function onShare() {
    shareModal({ document, compoundKey })
  }

  function onConfiguration() {
    setShowConfigurationModal(true)
  }

  const title = isCloudDocument(compoundKey)
    ? 'Rename document. Document is stored in the cloud'
    : 'Rename document. Document is stored locally in your browser'

  // attach a global event listener to listen for hot keys
  // only react when this panel has focus, that is when this
  // panel had the last mouse or keyboard event of all panels.
  useEffect(() => {
    async function onDocumentKeyDown(event) {
      const key = event.key.toUpperCase()

      // Save
      if (event.ctrlKey && !event.shiftKey && key === 'S') {
        event.preventDefault()
        event.stopPropagation()

        await onSave()
      }

      // Open
      if (event.ctrlKey && !event.shiftKey && key === 'O') {
        event.preventDefault()
        event.stopPropagation()

        await onOpen()
      }

      // Document properties
      if (event.ctrlKey && event.altKey && !event.shiftKey && key === 'I') {
        event.preventDefault()
        event.stopPropagation()

        onDocumentProperties()
      }
    }

    if (focus) {
      debug('addEventListener for global keydown panelId:', panelId)
      window.document.body.addEventListener('keydown', onDocumentKeyDown)

      return () => {
        debug('removeEventListener for global keydown panelId:', panelId)
        window.document.body.removeEventListener('keydown', onDocumentKeyDown)
      }
    }
  }, [focus, panelId, onOpen, onSave, onDocumentProperties])

  function applyFocus() {
    if (jsonEditorRef && jsonEditorRef.focus) {
      jsonEditorRef.focus()
    }
  }

  return (
    <div className="panel" ref={observePanel}>
      <FileDrop onDrop={(files) => loadFromDisk(files[0])}>
        {/*
        It would be nice to change the text when hovering it,
        but that gives some issues on both Firefox and Chrome
        when dragging over this text (which changes on the fly)
        */}
        Drag `&apos;n drop your JSON document here...
      </FileDrop>
      <div className={classnames('panel-menu', { wrap: wrapMenu })}>
        <div className="document-details" ref={observeDocumentDetails}>
          <div
            className="local-storage-error-icon"
            data-tip={String(localStorageError)}
            style={{ display: localStorageError ? '' : 'none' }}
          >
            <FontAwesomeIcon icon={faExclamationTriangle} />
          </div>

          {document.schema && document.schema.type !== 'NONE' && (
            <button
              className={classnames('menu-button schema', { error: schema.error })}
              disabled={loading || error}
              onClick={onSchema}
              title={
                schema.error
                  ? `Failed to load JSON Schema: ${schema.error}`
                  : schema.loading
                  ? 'Loading JSON schema...'
                  : 'This document is validated against a JSON schema. Click to view or change the schema.'
              }
            >
              {schema.loading ? (
                <FontAwesomeIcon icon={faCircleNotch} spin fixedWidth />
              ) : (
                <JSONSchemaIcon backgroundColor="#6f9970" />
              )}
              {schema.error && <span className="error">Error</span>}
            </button>
          )}

          {!loading && document && document._id ? (
            <button
              disabled={loading || error}
              className={classnames('menu-button name', { unnamed: !document.name })}
              title={title}
              onClick={onRename}
            >
              {isCloudDocument(compoundKey) ? <FontAwesomeIcon icon={faCloud} /> : null}
              {document.name}
              <FontAwesomeIcon icon={faEdit} />
            </button>
          ) : null}
        </div>
        {showChangesText ? (
          <div className={classnames('unsaved-changes', { visible: showChanges })}>
            changed (
            <button className="save-now" onClick={onSave}>
              save now
            </button>
            )
          </div>
        ) : (
          <button
            className={classnames('menu-button unsaved-changes', { visible: showChanges })}
            onClick={onSave}
            title="There are unsaved changes. Click to save now."
          >
            <FontAwesomeIcon icon={faSaveRegular} />
          </button>
        )}
        <div className="space"></div>
        <div className="buttons">
          <button
            className="menu-button"
            disabled={loading}
            onClick={onNew}
            title="Open a new, empty document"
          >
            <FontAwesomeIcon icon={faFile} />
            {showButtonsText && ' New'}
          </button>

          <div className="menu-button dropdown-button">
            <FontAwesomeIcon icon={faFolderOpen} />
            {showButtonsText && ' Open'} <FontAwesomeIcon icon={faCaretDown} />
            <div className="dropdown-menu right">
              <button
                className="dropdown-menu-button"
                disabled={loading}
                onClick={onOpen}
                title="Open a recent document from the cloud or local storage"
              >
                <FontAwesomeIcon icon={faCloud} fixedWidth /> Open recent file
              </button>
              <input
                type="file"
                ref={refSelectFile}
                onChange={(event) => loadFromDisk(event.target.files[0])}
                style={{ display: 'none' }}
              />
              <button
                className="dropdown-menu-button"
                disabled={loading}
                onClick={() => refSelectFile.current.click()}
                title="Open a document from disk"
              >
                <FontAwesomeIcon icon={faLaptop} fixedWidth /> Open from disk
              </button>
              <button
                className="dropdown-menu-button"
                disabled={loading}
                onClick={onLoadFromUrl}
                title="Open a document from url"
              >
                <FontAwesomeIcon icon={faLink} fixedWidth /> Open from url
              </button>
            </div>
          </div>

          <div className="menu-button dropdown-button">
            <FontAwesomeIcon icon={faSave} />
            {showButtonsText && ' Save'} <FontAwesomeIcon icon={faCaretDown} />
            <div className="dropdown-menu right">
              <button
                className="dropdown-menu-button"
                disabled={loading || error}
                onClick={onSaveToCloud}
                title="Save this document in the cloud"
              >
                <FontAwesomeIcon icon={faCloud} fixedWidth /> Save to cloud
              </button>
              <button
                className="dropdown-menu-button"
                disabled={loading || error}
                onClick={onSaveToDisk}
                title="Save this document to disk"
              >
                <FontAwesomeIcon icon={faLaptop} fixedWidth /> Save to disk
              </button>
              <button
                className="dropdown-menu-button"
                disabled={loading || error}
                onClick={onSaveToUrl}
                title="Save this document to a public url"
              >
                <FontAwesomeIcon icon={faLink} fixedWidth /> Send to url
              </button>
              <div className="dropdown-menu-separator" />
              <button
                className="dropdown-menu-button"
                disabled={loading || error}
                onClick={onExportToCSV}
                title="Export the JSON document to CSV (comma separated values)"
              >
                <FontAwesomeIcon icon={faTable} fixedWidth /> Export to CSV
              </button>
            </div>
          </div>

          <div className="menu-button dropdown-button dropdown-with-default">
            <button
              className="dropdown-menu-button-default"
              disabled={loading}
              onClick={() => onCopy(Formatting.KEEP)}
              title="Copy this document to the system clipboard"
            >
              <FontAwesomeIcon icon={faCopy} />
              {showButtonsText && ' Copy'} <FontAwesomeIcon icon={faCaretDown} />
            </button>
            <div className="dropdown-menu">
              <button
                className="dropdown-menu-button"
                disabled={loading}
                onClick={() => onCopy(Formatting.FORMAT)}
                title="Copy this document to the system clipboard in formatted form"
              >
                <FontAwesomeIcon icon={faCopy} /> Copy formatted
              </button>
              <button
                className="dropdown-menu-button"
                disabled={loading}
                onClick={() => onCopy(Formatting.COMPACT)}
                title="Copy this document to the system clipboard in compacted form"
              >
                <FontAwesomeIcon icon={faCopy} /> Copy compacted
              </button>
              <button
                className="dropdown-menu-button"
                disabled={loading}
                onClick={() => onCopy(Formatting.KEEP)}
                title="Copy this document to the system clipboard without changing indentation"
              >
                <FontAwesomeIcon icon={faCopy} /> Copy as-is
              </button>
            </div>
          </div>

          <button
            className="menu-button"
            disabled={loading || error}
            onClick={onShare}
            title="Share"
          >
            <FontAwesomeIcon icon={faShareAlt} />
            {showButtonsText && ' Share'}
          </button>

          <div className="menu-button dropdown-button">
            <FontAwesomeIcon icon={faCog} />
            {showButtonsText && ' Options'} <FontAwesomeIcon icon={faCaretDown} />
            <div className="dropdown-menu">
              <button
                className="dropdown-menu-button"
                disabled={loading || error}
                onClick={onSchema}
                title="Configure a JSON schema to validate this document"
              >
                <JSONSchemaIcon /> Configure JSON Schema
              </button>
              <button
                className="dropdown-menu-button"
                onClick={onConfiguration}
                title={`Change configuration: fontSize, indentation, escaping of special characters`}
              >
                <FontAwesomeIcon icon={faGear} fixedWidth /> Configure editor
              </button>
              <button
                className="dropdown-menu-button"
                disabled={loading || error}
                onClick={onDocumentProperties}
                title="See document properties (Ctrl+Alt+I)"
              >
                <FontAwesomeIcon icon={faInfo} fixedWidth /> Document properties
              </button>
              <button
                className="dropdown-menu-button"
                disabled={loading || error || !document._id}
                onClick={onDeleteDocument}
                title="Delete document"
              >
                <FontAwesomeIcon icon={faTimes} fixedWidth /> Delete document
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className={classnames('panel-contents', { error })}>
        <JSONEditorComponent
          id={panelId}
          onJsonEditorRef={(ref) => {
            setJsonEditorRef(ref)
            jsonEditorRefCopy.current = ref
            debug('new ref', ref)
          }}
          mode={mode}
          parser={parser}
          indentation={indentation}
          tabSize={tabSize}
          escapeControlCharacters={escapeControlCharacters}
          escapeUnicodeCharacters={escapeUnicodeCharacters}
          flattenColumns={flattenColumns}
          content={content}
          queryLanguageId={queryLanguageId}
          onChangeQueryLanguage={onChangeQueryLanguage}
          onChange={updateContent}
          onChangeMode={setMode}
          onClassName={diff ? handleClassName : undefined}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          schema={schema.content}
        />
        {loading ? (
          <div className="overlay">
            <div className="loading">
              <FontAwesomeIcon icon={faCircleNotch} spin fixedWidth /> loading...
            </div>
          </div>
        ) : null}
        {error ? (
          <div className="overlay">
            <LoadingError error={error} onNew={onNew} />
          </div>
        ) : null}
      </div>
      {showCSVExportModal && (
        <CSVExportModal
          parser={parser}
          document={document}
          onClose={() => setShowCSVExportModal(false)}
        />
      )}
      {showConfigurationModal && (
        <ConfigurationModal
          config={{
            fontSize,
            indentation,
            tabSize,
            escapeControlCharacters,
            escapeUnicodeCharacters,
            flattenColumns,
            parserId
          }}
          onOk={(updatedConfig) => {
            debug('configuration updated', updatedConfig)
            setFontSize(updatedConfig.fontSize)
            setIndentation(updatedConfig.indentation)
            setTabSize(updatedConfig.tabSize)
            setEscapeControlCharacters(updatedConfig.escapeControlCharacters)
            setEscapeUnicodeCharacters(updatedConfig.escapeUnicodeCharacters)
            setFlattenColumns(updatedConfig.flattenColumns)
            setParserId(updatedConfig.parserId)
          }}
          onClose={() => setShowConfigurationModal(false)}
        />
      )}

      {showOpenUrlPrompt && (
        <Prompt
          className="open-url-prompt"
          title="Open url"
          text={
            <div>
              <p>Enter a public url.</p>
              <p>
                Urls which are unsecure (http) or do not have CORS enabled can be loaded via the
                proxy when they have a public url. Urls which need authentication cannot be loaded.
              </p>
            </div>
          }
          value={document.loadedFromUrl ? fromProxyUrl(document.loadedFromUrl) : ''}
          checkboxText="Use proxy"
          checkboxTitle="The request will be routed via the backend of jsoneditoronline.org to work around unsecure urls (http) and CORS limitations"
          checkboxValue={isProxyUrl(document.loadedFromUrl)}
          textOk="Open"
          onOk={(url, optionValue, checkboxValue) => {
            debug('Open from url', { url, optionValue, checkboxValue })

            const processedUrl = checkboxValue ? toProxyUrl(url) : url

            loadFromUrl(`url.${processedUrl}`)
          }}
          onClose={() => setShowOpenUrlPrompt(false)}
        />
      )}

      <StyledReactTooltip />
    </div>
  )
}

function JSONSchemaIcon({ valid, backgroundColor }) {
  const isValid = valid !== false
  const style = {
    color: backgroundColor || 'white',
    position: 'absolute',
    bottom: 2,
    left: 4,
    fontSize: '60%'
  }

  // TODO: use font awesome icon 'file-check' instead? (pro)
  return (
    <div style={{ position: 'relative', display: 'inline-block' }}>
      <FontAwesomeIcon icon={faFile} fixedWidth />
      <FontAwesomeIcon style={style} icon={isValid ? faCheck : faTimes} fixedWidth />
    </div>
  )
}
