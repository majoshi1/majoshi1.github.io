import { loadFromLocalStorage, saveToLocalStorage } from './utils/localStorageUtils'
import { isoDateNow } from './utils/dateUtils'

const RECENT_FILES_KEY = 'recentFiles'
const LEGACY_RECENT_FILES_KEY = 'files'
const MAX_RECENT_FILES = 1000

/**
 * @param {CompoundKey} compoundKey
 * @param {Document} document
 */
export function addRecentFile(compoundKey, document) {
  const recentFiles = listRecentFiles().filter((file) => file.compoundKey !== compoundKey)

  recentFiles.unshift({
    compoundKey,
    name: document.name || `Unnamed document (${document._id})`,
    updated: document.updated,
    accessed: isoDateNow()
  })

  saveToLocalStorage(RECENT_FILES_KEY, limit(recentFiles, MAX_RECENT_FILES))
}

/**
 * @param {CompoundKey} compoundKey
 */
export function removeRecentFile(compoundKey) {
  const recentFiles = listRecentFiles().filter((file) => file.compoundKey !== compoundKey)

  saveToLocalStorage(RECENT_FILES_KEY, recentFiles)
}

export function listRecentFiles() {
  const recentFiles = loadFromLocalStorage(RECENT_FILES_KEY)
  if (recentFiles) {
    return recentFiles.map((recentFile) => {
      // backward compatibility since refactoring in April 2020
      return typeof recentFile.id === 'string' && typeof recentFile.source === 'string'
        ? {
            compoundKey: `${recentFile.source}.${recentFile.id}`,
            name: recentFile.name,
            updated: recentFile.updated,
            accessed: recentFile.accessed
          }
        : recentFile
    })
  }

  const recentFilesFromLegacy = listLegacyRecentFiles()
  if (recentFilesFromLegacy) {
    return recentFilesFromLegacy
  }

  return []
}

// TODO: remove this legacy mechanism some day
function listLegacyRecentFiles() {
  // legacy:
  //   {
  //     "4deb0f3c66c744d495f777a2d65d37f9": {
  //        "_id": "4deb0f3c66c744d495f777a2d65d37f9",
  //        "_rev": 125,
  //        "name": "Employee (John Smith)",
  //        "updated": "2020-01-04T08:37:34.700Z"
  //      }
  //   }
  // new:
  //   [
  //     {
  //       "compoundKey": "cloud.4deb0f3c66c744d495f777a2d65d37f9",
  //       "name": "Employee (John Smith)",
  //       "updated": "2020-01-04T08:37:34.566Z",
  //       "accessed": "2020-01-04T08:38:30.672Z"
  //     }
  //   ]
  const legacyFilesMap = loadFromLocalStorage(LEGACY_RECENT_FILES_KEY)

  if (!legacyFilesMap) {
    return undefined
  }

  return Object.values(legacyFilesMap).map((legacyFile) => {
    return {
      compoundKey: `cloud.${legacyFile._id}`,
      name: legacyFile.name,
      updated: legacyFile.updated,
      accessed: legacyFile.updated
    }
  })
}

function limit(array, maxLength) {
  return array.slice(0, maxLength)
}
