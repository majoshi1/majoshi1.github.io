import { faCircleHalfStroke, faMoon, faSun } from '@fortawesome/free-solid-svg-icons'

export const LEFT_PANEL_ID = 'LEFT_PANEL'
export const RIGHT_PANEL_ID = 'RIGHT_PANEL'
export const TRANSFORM_LEFT_TO_RIGHT_ID = 'TRANSFORM_LEFT_TO_RIGHT_ID'
export const TRANSFORM_RIGHT_TO_LEFT_ID = 'TRANSFORM_RIGHT_TO_LEFT_ID'

export const PANEL_NAMES = {
  [LEFT_PANEL_ID]: 'Left',
  [RIGHT_PANEL_ID]: 'Right'
}

export const PANEL_NAMES_LOWERCASE = {
  [LEFT_PANEL_ID]: 'left',
  [RIGHT_PANEL_ID]: 'right'
}

export const LARGE_DOCUMENT_SIZE = 10 * 1000 * 1000 // 10 MB
export const MAX_LOCAL_DOCUMENT_SIZE = 1000 * 1000 // 1 MB
export const MAX_PREVIEW_CHARACTERS = 20000

export const DocumentSource = {
  CLOUD: 'cloud',
  LOCAL: 'local',
  URL: 'url',
  JSON: 'json'
}

export const PLAYWIRE_SMALL_ADS_THRESHOLD = 1580 // pixels screen with

export const DOCUMENT_SOURCE_DESCRIPTIONS = {
  [DocumentSource.CLOUD]: 'stored in the cloud, sharable',
  [DocumentSource.LOCAL]: 'stored locally in your browser',
  [DocumentSource.URL]: 'document is loaded via an url',
  [DocumentSource.JSON]: 'document is stored in the url itself'
}

export const Formatting = {
  KEEP: 'keep',
  FORMAT: 'format',
  COMPACT: 'compact'
}

export const FORMATTING_OPTIONS = [
  { value: Formatting.KEEP, text: 'keep as-is' },
  { value: Formatting.FORMAT, text: 'format' },
  { value: Formatting.COMPACT, text: 'compact' }
]

export const THEME = {
  AUTO: 'auto',
  LIGHT: 'light',
  DARK: 'dark'
}

export const THEME_ICONS = {
  [THEME.AUTO]: faCircleHalfStroke,
  [THEME.LIGHT]: faSun,
  [THEME.DARK]: faMoon
}

export const THEME_DESCRIPTION = {
  [THEME.AUTO]: 'Browser default',
  [THEME.LIGHT]: 'Light',
  [THEME.DARK]: 'Dark'
}

export const THEME_COLOR = {
  GREEN: 'default',
  BLUE: 'blue',
  RED: 'red'
}

export const THEME_COLOR_CLASSNAME = {
  [THEME_COLOR.GREEN]: 'jse-theme-color-green',
  [THEME_COLOR.BLUE]: 'jse-theme-color-blue',
  [THEME_COLOR.RED]: 'jse-theme-color-red'
}

export const PROXY_URL_BASE = 'https://jsoneditoronline.herokuapp.com/v1/forwarder/url?url='
