import { PureComponent } from 'react'
import './ErrorBoundary.scss'

export default class ErrorBoundary extends PureComponent {
  constructor(props) {
    super(props)

    this.state = {
      error: undefined
    }
  }

  static getDerivedStateFromError(error) {
    return {
      error
    }
  }

  componentDidCatch(error, errorInfo) {
    console.error(error, errorInfo)
  }

  render() {
    if (this.state.error) {
      return (
        <div className="error-boundary">
          <div>Something went wrong. Please reload the application.</div>
          <div>{this.state.error.toString()}</div>
        </div>
      )
    }
    return this.props.children
  }
}
