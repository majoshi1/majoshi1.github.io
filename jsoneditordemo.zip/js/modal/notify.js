import React from 'react'
import './notify.scss'
import classnames from 'classnames'
import { faTimes } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { getAdsSize } from '../Ads'
import { createRoot } from 'react-dom/client'

/**
 * Show a notification.
 * The notification can optionally be closed by the user or after a delay.
 *
 * Usage:
 *
 *   const notification = notify({
 *     text: string | React.Component,
 *     closable: boolean,         // can be closed
 *     timeout: number            // if defined, notification will close after the timeout in ms
 *     className: string
 *   })
 *
 *   notification.close();
 *
 * Example:
 *
 *   notify({
 *     text: 'Document has been saved',
 *     closable: false,
 *     timeout: 3000, // ms
 *   });
 *
 */
class Notifications extends React.PureComponent {
  constructor(props) {
    super(props)

    this.state = {
      notifications: [],
      adsClassName: getAdsSize().className
    }

    this.notify = this.notify.bind(this)
    this.close = this.close.bind(this)

    props.getNotify(this.notify)
  }

  render() {
    const notifications = this.state.notifications.map((notification, index) => {
      let close
      if (notification.closable) {
        const handleClose = () => this.close(notification)

        close = (
          <div className="close" onClick={handleClose}>
            <FontAwesomeIcon icon={faTimes} />
          </div>
        )
      }

      const className = classnames('notification', notification.className, {
        closable: notification.closable
      })

      return (
        <div className={className} key={index}>
          {notification.text}
          {close}
        </div>
      )
    })

    return (
      <div className={classnames('notification-list', this.state.adsClassName)}>
        <div className="notification-list-items">{notifications}</div>
      </div>
    )
  }

  close(notification) {
    this.setState({
      notifications: this.state.notifications.filter((item) => {
        return item !== notification
      })
    })
  }

  notify(notification) {
    this.setState({
      notifications: [...this.state.notifications, notification]
    })

    const close = () => this.close(notification)

    // close after the timeout
    if (notification.timeout) {
      setTimeout(close, notification.timeout)
    }

    return { close }
  }
}

// singleton, holds a list with notifications
let singletonNotify = null
const container = document.createElement('div')
document.body.appendChild(container)
createRoot(container).render(
  <Notifications
    container={container}
    getNotify={(notify) => {
      singletonNotify = notify
    }}
  />
)

/**
 * Show a notification
 * @param {Object} notification   Object with parameters. Available parameters:
 *                          - text:       string | React.Component
 *                          - closable:  boolean
 *                          - timeout:    number
 *                          - className:  string
 */
export default function notify(notification) {
  return singletonNotify(notification)
}
