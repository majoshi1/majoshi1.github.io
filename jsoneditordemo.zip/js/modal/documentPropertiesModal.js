import React from 'react'
import { DOCUMENT_SOURCE_DESCRIPTIONS } from '../constants'
import { formatDate } from '../utils/dateUtils'
import { getContentsDescription, splitCompoundKey, stringifyContent } from '../utils/documentUtils'
import { formatSize } from '../utils/fileUtils'
import './documentPropertiesModal.scss'
import Modal from './modal'
import { createRoot } from 'react-dom/client'

function DocumentPropertiesModal({ document, compoundKey, onClose }) {
  const { documentSource } = splitCompoundKey(compoundKey)
  const documentSourceDescription = DOCUMENT_SOURCE_DESCRIPTIONS[documentSource]

  return (
    <Modal onRequestClose={onClose} className="document-properties">
      <div className="modal modal-document-properties">
        <h1>Document properties</h1>

        <table className="properties">
          <tbody>
            <tr>
              <th>Name</th>
              <td>{document.name || '-'}</td>
            </tr>
            <tr>
              <th>Storage</th>
              <td>
                {documentSource || '-'}
                {documentSourceDescription ? ` (${documentSourceDescription})` : ''}
              </td>
            </tr>
            <tr>
              <th>Updated</th>
              <td>{document.updated ? formatDate(document.updated) : '-'}</td>
            </tr>
            <tr>
              <th>Contents</th>
              <td>{getContentsDescription(document.content)}</td>
            </tr>
            <tr>
              <th>Size</th>
              <td>
                {
                  formatSize(stringifyContent(document.content, JSON).length) // we use the native JSON parser here, we only need the length
                }
              </td>
            </tr>
          </tbody>
        </table>

        <div className="modal-action-menu">
          <button className="modal-button" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </Modal>
  )
}

/**
 * Show a modal with document details
 * @param {Object} props    Object with parameters. Available parameters:
 * @property {Document} document
 * @property {CompoundKey} compoundKey
 */
export default function documentPropertiesModal(props) {
  const container = document.createElement('div')
  document.body.appendChild(container)

  function handleClose() {
    document.body.removeChild(container)
  }

  createRoot(container).render(<DocumentPropertiesModal {...props} onClose={handleClose} />)
}
