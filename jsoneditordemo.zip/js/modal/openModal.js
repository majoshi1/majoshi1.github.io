import Modal from './modal'
import React, { useEffect, useRef, useState } from 'react'
import { listRecentFiles } from '../recentFiles'
import { isEmpty } from 'lodash'
import './openModal.scss'
import { formatDate } from '../utils/dateUtils'
import confirm from './confirm.js'
import classnames from 'classnames'
import { faCloud, faTimes } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { isCloudDocument, splitCompoundKey } from '../utils/documentUtils'
import { createRoot } from 'react-dom/client'

// FIXME: rename onOpen to onOpenFromCloud, onDeleteFromCloud?
function OpenModal({ onOpen, onClose, onDelete }) {
  const refModal = useRef(null)
  const refSearchText = useRef(null)
  const [searchText, setSearchText] = useState('')
  const [recentFiles, setRecentFiles] = useState(listRecentFiles())
  const [deletingFileIds, setDeletingFileIds] = useState({})

  const hasSearchText = !isEmpty(searchText.trim())
  const filteredRecentFiles = hasSearchText
    ? recentFiles.filter((recentFile) => {
        return recentFile.name.toLowerCase().includes(searchText.toLowerCase())
      })
    : recentFiles

  // set focus to search field
  useEffect(() => {
    if (refSearchText.current) {
      refSearchText.current.focus()
    }
  }, [refSearchText])

  function close() {
    refModal.current.close()
    onClose()
  }

  function handleOpen(compoundKey) {
    close()
    onOpen(compoundKey)
  }

  async function handleDelete(compoundKey, name = splitCompoundKey(compoundKey).documentId) {
    confirm({
      title: 'Delete document',
      text: `Are you sure you want to delete document "${name}"?`,
      textOk: 'Delete',
      classOk: 'danger',
      onOk: async () => {
        setDeletingFileIds({
          ...deletingFileIds,
          [compoundKey]: true
        })

        await onDelete(compoundKey)

        // refresh the list
        setRecentFiles(listRecentFiles())

        setDeletingFileIds({
          ...deletingFileIds,
          [compoundKey]: false
        })
      }
    })
  }

  function handleCancel() {
    close()
  }

  return (
    <Modal ref={refModal} onRequestClose={handleCancel}>
      <div className="modal modal-open">
        <h1>Open a recent file</h1>
        <div className="search-box">
          <span className="label">Search:</span>
          <input
            ref={refSearchText}
            className="search-text"
            placeholder="Enter a document name..."
            value={searchText}
            onChange={(event) => setSearchText(event.target.value)}
          />
        </div>
        <div className="info">
          {hasSearchText
            ? `Showing ${filteredRecentFiles.length} out of ${recentFiles.length} documents`
            : `Showing ${recentFiles.length} documents`}
        </div>
        <div className="recent-files">
          {!isEmpty(filteredRecentFiles) ? (
            filteredRecentFiles.map((file) => {
              const deleting = deletingFileIds[file.compoundKey] || false
              const className = classnames({
                'recent-file': true,
                deleting
              })

              return (
                <div key={file.compoundKey} className={className}>
                  <button
                    className="modal-button open"
                    title="Click to open this document"
                    disabled={deleting}
                    onClick={() => handleOpen(file.compoundKey)}
                  >
                    {isCloudDocument(file.compoundKey) && (
                      <span title="This document is stored in the cloud">
                        <FontAwesomeIcon icon={faCloud} />{' '}
                      </span>
                    )}
                    {file.name}
                    {deleting ? ' (deleting...)' : null}
                    <div className="updated">
                      Last modified: {file.updated ? formatDate(file.updated) : '(unknown)'}
                    </div>
                  </button>
                  <button
                    className="modal-button remove"
                    disabled={deleting}
                    title="Click to delete this document"
                    onClick={() => handleDelete(file.compoundKey, file.name)}
                  >
                    <FontAwesomeIcon icon={faTimes} />
                  </button>
                </div>
              )
            })
          ) : (
            <div className="no-files">(no recent files)</div>
          )}
        </div>
        <div className="modal-action-menu">
          <button className="modal-button" onClick={handleCancel}>
            Cancel
          </button>
        </div>
      </div>
    </Modal>
  )
}

/**
 * Show a modal to open files
 * @param {Object} props    Object with parameters. Available parameters:
 * @property {function(compoundKey: CompoundKey)} onOpen
 * @property {function(compoundKey: CompoundKey)} onDelete
 */
export default function openModal(props) {
  const container = document.createElement('div')
  document.body.appendChild(container)

  function handleClose() {
    document.body.removeChild(container)
  }

  createRoot(container).render(
    <OpenModal onOpen={props.onOpen} onDelete={props.onDelete} onClose={handleClose} />
  )
}
