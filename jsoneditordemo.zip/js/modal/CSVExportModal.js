import {
  faCircleNotch,
  faExclamationTriangle,
  faSave,
  faTable
} from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React, { useEffect, useState } from 'react'
import './CSVExportModal.scss'
import Modal from './modal'
import { parseContent } from '../utils/documentUtils'
import CopyToClipboardButton from '../controls/CopyToClipboardButton'
import { addExtensionIfNeeded, saveFileViaAnchor } from '../utils/fileUtils'
import { notifyError } from '../utils/modalUtils'
import useLocalStorage from '../hooks/useLocalStorage'
import { truncate } from 'lodash'
import { MAX_PREVIEW_CHARACTERS } from '../constants'
import { jsonToCsv } from '../utils/jsonUtils'
import createDebug from 'debug'
import useTimeout from '../hooks/useTimeout'
import classnames from 'classnames'
import { memoizeLastArguments } from '../utils/memoizationUtils'
import { transform } from 'immutable-json-patch/lib/esm/immutabilityHelpers' // TODO: expose the function transform in the library

const debug = createDebug('jsoneditoronline:CSVExportModal')

const defaultOptions = {
  header: true,
  flatten: true
}

export default function CSVExportModal({ parser, document, onClose }) {
  const content = document.content

  const [options, setOptions] = useLocalStorage('csvExportOptions', defaultOptions)
  const [name, setName] = useState(document.name || 'document')
  const [loading, setLoading] = useState(true)
  const [preview, setPreview] = useState({
    content: undefined,
    json: undefined,
    csv: undefined,
    csvTruncated: undefined,
    error: undefined
  })
  const [setLoadingTimeout] = useTimeout()

  useEffect(() => {
    setLoadingTimeout(() => {
      setPreview(createPreview(content, parser, options))
      setLoading(false)
    })
  }, [])

  function applyOptions(newOptions) {
    debug('applyOptions', newOptions)

    const updatedOptions = {
      ...options,
      ...newOptions
    }

    setOptions(updatedOptions)
    setLoading(true)

    setLoadingTimeout(() => {
      setPreview(createPreview(content, parser, updatedOptions))
      setLoading(false)
    })
  }

  function handleSave() {
    try {
      const filename = addExtensionIfNeeded(name, '.csv')

      saveFileViaAnchor(filename, preview.csv)

      onClose()
    } catch (error) {
      console.error(error)
      notifyError(error)
    }
  }

  return (
    <Modal onRequestClose={onClose} className="csv-export">
      <div className="modal modal-csv-export">
        <div className="modal-header">
          <h1>
            <FontAwesomeIcon icon={faTable} /> CSV Export
          </h1>
        </div>

        <div className="modal-contents">
          <div className="modal-text">Enter a name for the CSV file:</div>
          <input
            type="text"
            className="regular"
            value={name}
            onChange={(event) => setName(event.target.value)}
          />

          <div className="modal-text">
            Options:
            <label title="When selected, the first line of the CSV will be a header with the column names">
              <input
                type="checkbox"
                checked={options.header === true}
                onChange={(event) => {
                  applyOptions({ header: event.target.checked })
                }}
              />{' '}
              Header row
            </label>
            <label title="When selected, an array containing objects with nested properties will be flattened">
              <input
                type="checkbox"
                checked={options.flatten}
                onChange={(event) => {
                  applyOptions({ flatten: event.target.checked })
                }}
              />{' '}
              Flatten nested properties
            </label>
          </div>

          <div className={classnames('preview-area', { loading })}>
            <textarea
              readOnly
              wrap={!preview.error ? 'off' : ''}
              className={classnames('regular', 'csv-preview', { error: !!preview.error })}
              value={
                loading
                  ? ''
                  : preview.error
                  ? `Error: could not parse JSON. Please close the CSV Export modal, fix your JSON document, then export to CSV again.`
                  : preview.csvTruncated || ''
              }
            />

            {loading && (
              <div className="overlay">
                <div className="loading">
                  <FontAwesomeIcon icon={faCircleNotch} spin /> loading...
                </div>
              </div>
            )}

            {!loading && preview.csvTruncated !== preview.csv && (
              <div className="truncated-overlay">
                <div className="truncated">
                  <FontAwesomeIcon icon={faExclamationTriangle} /> Preview is truncated
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="modal-action-menu">
          <CopyToClipboardButton
            data={preview.csv}
            text="Copy to clipboard"
            copiedText="Copied to clipboard!"
            title="Copy CSV data to clipboard"
            className="modal-button primary"
          />
          <button className="modal-button primary" onClick={handleSave}>
            <FontAwesomeIcon icon={faSave} /> Save to disk
          </button>
          <button className="modal-button" onClick={() => onClose()}>
            Close
          </button>
        </div>
      </div>
    </Modal>
  )
}

/**
 * @param {JSON} parser
 * @param {Content} content
 * @returns {{json: JSON, error: undefined} | {json: undefined, error: Error}}
 */
function tryParseContent(content, parser) {
  try {
    const json = parseContent(content, parser)
    return {
      json,
      error: undefined
    }
  } catch (error) {
    return {
      json: undefined,
      error
    }
  }
}

const tryParseContentMemoized = memoizeLastArguments(tryParseContent)

function createPreview(content, parser, options) {
  try {
    debug('createPreview')
    console.time('parse')
    const { json, error } = tryParseContentMemoized(content, parser)
    console.timeEnd('parse')

    if (error) {
      return {
        content,
        json: undefined,
        csv: undefined,
        csvTruncated: undefined,
        error
      }
    }

    console.time('to csv')
    const csv = jsonToCsv(ensureCSVSafeJSON(json), options)
    console.timeEnd('to csv')

    const csvTruncated =
      typeof csv === 'string'
        ? truncate(csv, { length: MAX_PREVIEW_CHARACTERS, separator: '\n', omission: '\n...' })
        : undefined

    return {
      content,
      json,
      csv,
      csvTruncated,
      error: undefined
    }
  } catch (error) {
    return {
      content,
      json: undefined,
      csv: undefined,
      csvTruncated: undefined,
      error
    }
  }
}

// If needed, convert LosslessNumbers to strings before transforming to JSON
// This is possible because strings and numbers are both written as a value with double quotes
function ensureCSVSafeJSON(json, parser) {
  return parser !== JSON
    ? transform(json, (entry) => {
        return entry && entry.isLosslessNumber ? entry.toString() : entry
      })
    : json
}
