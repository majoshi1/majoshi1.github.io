import React from 'react'
import { useAsync } from 'react-async-hook'
import { loadDocument } from '../../utils/documentUtils'
import './CloudDocumentSchemaPreview.scss'
import JSONEditorComponent from '../../JSONEditorComponent'

export default function CloudDocumentSchemaPreview({
  compoundKey,
  indentation,
  queryLanguageId,
  onChangeQueryLanguage
}) {
  return (
    <div className="cloud-document-schema-preview">
      Preview:
      <div className="preview">
        {compoundKey ? (
          <SchemaPreviewContents
            compoundKey={compoundKey}
            indentation={indentation}
            queryLanguageId={queryLanguageId}
            onChangeQueryLanguage={onChangeQueryLanguage}
          />
        ) : (
          <div className="info">(Select a document)</div>
        )}
      </div>
    </div>
  )
}

function SchemaPreviewContents({
  compoundKey,
  indentation,
  queryLanguageId,
  onChangeQueryLanguage
}) {
  const { loading, result, error } = useAsync(loadDocument, [compoundKey])

  if (error) {
    return <div className="error">{error.toString()}</div>
  }

  if (loading) {
    return <div className="loading">Loading...</div>
  }

  try {
    return (
      <JSONEditorComponent
        mode="tree"
        parser={JSON} // we use the native parser here, LossessJSON is not supported anyway by Ajv
        readOnly
        indentation={indentation}
        mainMenuBar={false}
        navigationBar={false}
        queryLanguageId={queryLanguageId}
        onChangeQueryLanguage={onChangeQueryLanguage}
        content={result.content}
      />
    )
  } catch (err) {
    console.error(err)
    return (
      <div className="error">
        Error: Cannot show preview. The selected document contains a JSON parse error.
      </div>
    )
  }
}
