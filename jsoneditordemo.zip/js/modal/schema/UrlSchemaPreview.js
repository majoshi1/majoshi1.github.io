import React from 'react'
import { useAsync } from 'react-async-hook'
import { loadUrl } from '../../rest'
import JSONEditorComponent from '../../JSONEditorComponent'

export default function UrlSchemaPreview({
  url,
  indentation,
  queryLanguageId,
  onChangeQueryLanguage
}) {
  const { loading, result, error } = useAsync(loadUrl, [url])

  return error ? (
    <div className="error">{error.toString()}</div>
  ) : loading ? (
    <div className="loading">Loading...</div>
  ) : (
    <JSONEditorComponent
      mode="tree"
      readOnly
      indentation={indentation}
      mainMenuBar={false}
      navigationBar={false}
      queryLanguageId={queryLanguageId}
      onChangeQueryLanguage={onChangeQueryLanguage}
      content={{ json: result }}
    />
  )
}
