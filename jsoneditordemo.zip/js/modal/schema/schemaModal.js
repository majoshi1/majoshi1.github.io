import Modal from '../modal'
import React, { useRef, useState } from 'react'
import './schemaModal.scss'
import Toggle from '../../controls/Toggle'
import { listRecentFiles } from '../../recentFiles'
import { formatDate } from '../../utils/dateUtils'
import { isEmpty } from 'lodash'
import classnames from 'classnames'
import { PANEL_NAMES, PANEL_NAMES_LOWERCASE } from '../../constants'
import UrlSchemaPreview from './UrlSchemaPreview'
import isUrl from 'is-url'
import PanelSchemaPreview from './PanelSchemaPreview'
import CloudDocumentSchemaPreview from './CloudDocumentSchemaPreview'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCloud } from '@fortawesome/free-solid-svg-icons'
import { isCloudDocument } from '../../utils/documentUtils'
import { createRoot } from 'react-dom/client'
import JSONEditorComponent from '../../JSONEditorComponent'

function SchemaModal({
  initialSchema,
  indentation,
  queryLanguageId,
  onChangeQueryLanguage,
  panelId,
  allPanels,
  onOk,
  onClose
}) {
  const refModal = useRef(null)
  const [schema, setSchema] = useState(initialSchema || { type: 'NONE' })

  const schemaParser = JSON // we use the native parser here, LossessJSON is not supported anyway by Ajv

  const schemaTypeOptions = [
    { value: 'NONE', text: 'None' },
    { value: 'PANEL', text: 'Panel' },
    { value: 'DOCUMENT', text: 'Document' },
    { value: 'TEXT', text: 'Text' },
    { value: 'URL', text: 'Url' }
  ]

  function close() {
    refModal.current.close()
    onClose()
  }

  function handleCancel() {
    close()
  }

  function handleOk() {
    onOk(cleanSchemaConfig(schema))
    close()
  }

  function handleChangeType(type) {
    const otherPanel = allPanels.find((panel) => panel.panelId !== panelId)

    setSchema({
      ...schema,
      type,
      panelId: schema.panelId === undefined && otherPanel ? otherPanel.panelId : schema.panelId
    })
  }

  function handleSelectPanel(panelId) {
    setSchema({ ...schema, panelId })
  }

  const recentFiles = listRecentFiles()

  const otherPanel = allPanels.find((panel) => panel.panelId !== panelId)

  return (
    <Modal ref={refModal} onRequestClose={handleCancel} className="schema">
      <div className="modal modal-schema">
        <h1>JSON schema</h1>
        <p>Configure a JSON schema for the {PANEL_NAMES_LOWERCASE[panelId]} panel:</p>
        <div className="contents">
          <Toggle options={schemaTypeOptions} value={schema.type} onChange={handleChangeType} />
          {schema.type === 'NONE' && <div className="config">No JSON Schema.</div>}
          {schema.type === 'PANEL' && (
            <div className="config">
              {schema.panelId ? (
                schema.panelId !== panelId ? (
                  <>
                    <p>{PANEL_NAMES[schema.panelId]} panel contents will be used as JSON Schema.</p>
                    <p>Preview:</p>
                    <div className="schema-panel-preview">
                      <PanelSchemaPreview
                        panelId={schema.panelId}
                        allPanels={allPanels}
                        parser={schemaParser}
                        indentation={indentation}
                        queryLanguageId={queryLanguageId}
                        onChangeQueryLanguage={onChangeQueryLanguage}
                      />
                    </div>
                  </>
                ) : (
                  <div className="error">
                    <p>
                      Error: Currently the {PANEL_NAMES_LOWERCASE[panelId]} panel itself is selected
                      as JSON Schema. This is not possible.
                    </p>
                    <p>
                      <button
                        className="fix-panel"
                        onClick={() => handleSelectPanel(otherPanel.panelId)}
                      >
                        Select {PANEL_NAMES_LOWERCASE[otherPanel.panelId]} panel
                      </button>
                    </p>
                  </div>
                )
              ) : null}
            </div>
          )}
          {schema.type === 'DOCUMENT' && (
            <div className="config cloud-document">
              <div className="list-column">
                Select a document as JSON Schema:
                <div className="recent-files">
                  {!isEmpty(recentFiles) ? (
                    recentFiles.map((file) => {
                      const className = classnames('modal-button', 'recent-file', {
                        selected: file.compoundKey === schema.compoundKey
                      })

                      return (
                        <button
                          key={file.compoundKey}
                          className={className}
                          title="Select this file as JSON Schema"
                          onClick={() => setSchema({ ...schema, compoundKey: file.compoundKey })}
                        >
                          {isCloudDocument(file.compoundKey) && (
                            <span title="This document is stored in the cloud">
                              <FontAwesomeIcon icon={faCloud} />{' '}
                            </span>
                          )}
                          {file.name}
                          <div className="updated">
                            Last modified: {file.updated ? formatDate(file.updated) : '(unknown)'}
                          </div>
                        </button>
                      )
                    })
                  ) : (
                    <div className="no-files">(no recent files)</div>
                  )}
                </div>
              </div>
              <div className="preview-column">
                <CloudDocumentSchemaPreview
                  compoundKey={schema.compoundKey}
                  queryLanguageId={queryLanguageId}
                  onChangeQueryLanguage={onChangeQueryLanguage}
                />
              </div>
            </div>
          )}
          {schema.type === 'TEXT' && (
            <div className="config config-jsoneditor">
              <p>Enter the contents of the JSON Schema:</p>
              <JSONEditorComponent
                className="text-schema"
                indentation={indentation}
                queryLanguageId={queryLanguageId}
                onChangeQueryLanguage={onChangeQueryLanguage}
                content={schema.content ? schema.content : { json: {} }}
                onChange={(content) => {
                  setSchema({ ...schema, content })
                }}
              />
            </div>
          )}
          {schema.type === 'URL' && (
            <div className="config">
              <p>Specify the url of the JSON Schema.</p>
              <p>
                The url must be public: it must not require authentication and needs to have CORS
                enabled.
              </p>
              <input
                className="regular schema-url"
                type="text"
                value={schema.url || ''}
                onChange={(event) => setSchema({ ...schema, url: event.target.value })}
              />
              <div>
                <p>Preview:</p>
                <div className="schema-url-preview">
                  {schema.url && isUrl(schema.url) ? (
                    <UrlSchemaPreview
                      url={schema.url}
                      indentation={indentation}
                      queryLanguageId={queryLanguageId}
                      onChangeQueryLanguage={onChangeQueryLanguage}
                    />
                  ) : (
                    <div className="info">(enter a valid url)</div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
        <div className="modal-action-menu">
          <button className="modal-button" onClick={handleCancel}>
            Cancel
          </button>
          <button className="modal-button primary" onClick={handleOk}>
            Ok
          </button>
        </div>
      </div>
    </Modal>
  )
}

/**
 * Show a modal to open files
 * @param {Object} props    Object with parameters. Available parameters:
 * @property {'LEFT_PANEL' | 'RIGHT_PANEL'} panelId
 * @property {Array.<{id: string, content: Content}>} allPanels
 * @property {Schema} initialSchema
 * @property {Schema} indentation
 * @property {string} queryLanguageId
 * @property {(queryLanguageId: string) => void} onChangeQueryLanguage
 * @property {function(schema: Schema)} onOk
 * // TODO: document options
 */
export default function schemaModal(props) {
  const container = document.createElement('div')
  document.body.appendChild(container)

  function handleClose() {
    document.body.removeChild(container)
  }

  createRoot(container).render(
    <SchemaModal
      panelId={props.panelId}
      allPanels={props.allPanels}
      initialSchema={props.initialSchema}
      indentation={props.indentation}
      queryLanguageId={props.queryLanguageId}
      onChangeQueryLanguage={props.onChangeQueryLanguage}
      onOk={props.onOk}
      onClose={handleClose}
    />
  )
}

/**
 * Remove all but the necessary fields for the given schema type
 * @param {SchemaConfig} schemaConfig
 * @return {SchemaConfig} schemaConfig
 */
function cleanSchemaConfig(schemaConfig) {
  const { type, url, compoundKey, content, panelId } = schemaConfig

  switch (type) {
    case 'NONE':
      return { type }

    case 'URL':
      return { type, url }

    case 'DOCUMENT':
      return { type, compoundKey }

    case 'TEXT':
      return { type, content }

    case 'PANEL':
      return { type, panelId }

    default:
      console.error('Unknown type of schemaConfig', schemaConfig)
      return schemaConfig
  }
}
