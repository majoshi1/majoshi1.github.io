import React from 'react'
import { PANEL_NAMES_LOWERCASE } from '../../constants'
import JSONEditorComponent from '../../JSONEditorComponent'

export default function PanelSchemaPreview({
  panelId,
  allPanels,
  indentation,
  queryLanguageId,
  onChangeQueryLanguage
}) {
  const selectedPanel = allPanels.find((panel) => panel.panelId === panelId)

  try {
    return selectedPanel ? (
      <JSONEditorComponent
        mode="tree"
        parser={JSON} // we use the native parser here, LossessJSON is not supported anyway by Ajv
        readOnly
        indentation={indentation}
        mainMenuBar={false}
        navigationBar={false}
        queryLanguageId={queryLanguageId}
        onChangeQueryLanguage={onChangeQueryLanguage}
        content={selectedPanel.document.content}
      />
    ) : (
      <div className="error">Error: Cannot show preview. Panel with id {panelId} not found.</div>
    )
  } catch (err) {
    return (
      <div className="error">
        Error: Cannot show preview. The {PANEL_NAMES_LOWERCASE[panelId]} panel contains a JSON parse
        error.
      </div>
    )
  }
}
