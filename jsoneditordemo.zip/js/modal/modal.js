import React from 'react'
import './modal.scss'
import classnames from 'classnames'

/**
 * Usage:
 *
 *     <Modal onRequestClose={function}>
 *       <h1>hello world!</h1>
 *     </Modal>
 *
 * Methods:
 *
 *     modal.close()    // cleans up global event listeners
 *
 */
export default class Modal extends React.PureComponent {
  constructor(props) {
    super(props)

    this.backgroundRef = null

    this.handleRequestClose = this.handleRequestClose.bind(this)
    this.handleKeyDown = this.handleKeyDown.bind(this)
    this.close = this.close.bind(this)
  }

  render() {
    return (
      <div
        ref={(element) => {
          this.backgroundRef = element
        }}
        className={classnames('modal-background', this.props.className)}
        onClick={this.handleRequestClose}
      >
        <div className={classnames('modal-foreground', this.props.className)}>
          {this.props.children}
        </div>
      </div>
    )
  }

  componentDidMount() {
    window.addEventListener('keydown', this.handleKeyDown)
    if (document.activeElement && typeof document.activeElement.blur === 'function') {
      document.activeElement.blur()
    }
  }

  componentWillUnmount() {
    window.removeEventListener('keydown', this.handleKeyDown)
  }

  handleRequestClose(event) {
    if (event.target === this.backgroundRef) {
      event.preventDefault()
      event.stopPropagation()

      this.props.onRequestClose()
    }
  }

  handleKeyDown(event) {
    if (event.which === 27) {
      // ESC
      event.preventDefault()
      event.stopPropagation()

      // We schedule triggering the onRequestClose callback.
      // In case of multiple open modals, the second one will cancel
      // sending onRequestClose of the first modal.
      clearTimeout(timeout)
      timeout = setTimeout(() => this.props.onRequestClose(), 0)
    }
  }

  close() {
    this.componentWillUnmount()
  }
}

let timeout = null
