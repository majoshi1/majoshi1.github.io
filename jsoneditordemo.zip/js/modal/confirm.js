import React from 'react'
import Modal from './modal.js'
import classnames from 'classnames'
import { createRoot } from 'react-dom/client'

/**
 * Show a confirmation modal
 *
 * Usage:
 *
 *   const modal = confirm.show({
 *     title: string | React.Component,
 *     text: string | React.Component,
 *     onOk: function,
 *     onCancel: function,
 *
 *     textOk: string,
 *     textCancel: string,
 *
 *     classOk: string,
 *     classCancel: string
 *   })
 *
 *   modal.close();
 *
 * Example:
 *
 *   confirm({
 *     title: 'Delete',
 *     text: 'Are your sure you want to delete this document?',
 *     onOk: function (value) {
 *       console.log('deleting file...');
 *     },
 *     onCancel: function () {
 *       console.loge('cancelled deleting file')
 *     }
 *   });
 *
 */
class Confirm extends React.PureComponent {
  constructor(props) {
    super(props)

    this.okRef = null
    this.modalRef = null

    this.handleCancel = this.handleCancel.bind(this)
    this.handleOk = this.handleOk.bind(this)
    this.close = this.close.bind(this)
  }

  render() {
    return (
      <Modal
        ref={(element) => {
          this.modalRef = element
        }}
        onRequestClose={this.handleCancel}
      >
        <div className="modal modal-confirm">
          <h1>{this.props.title}</h1>
          <div className="modal-text">{this.props.text}</div>
          <div className="modal-action-menu">
            <button
              className={classnames('modal-button', this.props.classCancel)}
              onClick={this.handleCancel}
            >
              {this.props.textCancel || 'Cancel'}
            </button>
            <button
              ref={(element) => {
                this.okRef = element
              }}
              onClick={this.handleOk}
              className={classnames('modal-button', 'primary', this.props.classOk)}
            >
              {this.props.textOk || 'Ok'}
            </button>
          </div>
        </div>
      </Modal>
    )
  }

  componentDidMount() {
    // modal will become visible, set focus to the input value
    setTimeout(() => this.okRef.focus())
  }

  handleOk(event) {
    event.preventDefault() // stop form submit

    this.close()

    if (this.props.onOk) {
      this.props.onOk()
    }
  }

  handleCancel() {
    this.close()

    if (this.props.onCancel) {
      this.props.onCancel()
    }
  }

  close() {
    this.modalRef.close()
    this.props.onClose()
  }
}

/**
 * Show a confirm modal
 * @param {Object} props    Object with parameters. Available parameters:
 *                          - title:      string | React.Component
 *                          - text:       string | React.Component
 *                          - onOk:       function
 *                          - onCancel:   function
 *                          - textOk:     string   optional, 'Ok' by default.
 *                          - textCancel: string   optional, 'Cancel' by default.
 *                          - classOk:     string  optional, 'primary' by default
 *                          - classCancel: string  optional, null by default
 */
export default function confirm(props) {
  const container = document.createElement('div')
  document.body.appendChild(container)

  function handleClose() {
    document.body.removeChild(container)
  }

  createRoot(container).render(<Confirm {...props} onClose={handleClose} />)
}
