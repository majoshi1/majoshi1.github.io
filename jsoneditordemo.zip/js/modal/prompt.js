import classnames from 'classnames'
import React from 'react'
import Modal from './modal.js'
import './prompt.scss'
import { createRoot } from 'react-dom/client'

/**
 * Show a prompt where the user can enter input
 *
 * Usage:
 *
 *   const modal = prompt.show({
 *     title: string | React.Component,
 *     text: string | React.Component,
 *     value: string | null,
 *     optionText: string | null,
 *     optionTitle: string | null,
 *     optionValue: * | null,
 *     optionOptions: Object<value: *, text: string>>[] | null,
 *     optionChange: (value: *) => void | null,
 *     checkboxText: string | null,
 *     checkboxTitle: string | null,
 *     checkboxValue: boolean | null,
 *     checkboxChange: (value: *) => void | null,
 *     onOk: function,
 *     onCancel: function,
 *     validate: function,
 *
 *     textOk: string,
 *     textCancel: string,
 *
 *     classOk: string,
 *     classCancel: string
 *   })
 *
 *   modal.close();
 *
 * Example:
 *
 *   prompt({
 *     title: 'Save document',
 *     text: 'Enter a title for the document:',
 *     value: 'myDocument',
 *     onOk: function (value) {
 *       console.log('save file as: ' + value);
 *     },
 *     onCancel: function () {
 *       console.loge('cancelled save file')
 *     }
 *   });
 *
 */
export class Prompt extends React.PureComponent {
  constructor(props) {
    super(props)

    this.state = {
      value: props.value,
      optionValue: props.optionValue || null,
      checkboxValue: props.checkboxValue || false,
      showValidationResult: false
    }

    this.valueRef = null
    this.modalRef = null

    this.handleOk = this.handleOk.bind(this)
    this.handleCancel = this.handleCancel.bind(this)
    this.handleChange = this.handleChange.bind(this)
    this.handleChangeOption = this.handleChangeOption.bind(this)
    this.handleChangeCheckbox = this.handleChangeCheckbox.bind(this)
    this.close = this.close.bind(this)
  }

  render() {
    const error =
      this.props.validate && this.state.showValidationResult
        ? this.props.validate(this.state.value)
        : null

    return (
      <Modal
        ref={(element) => {
          this.modalRef = element
        }}
        className={this.props.className}
        onRequestClose={this.handleCancel}
      >
        <div className="modal modal-prompt">
          <h1>{this.props.title}</h1>
          <div className="modal-text">{this.props.text}</div>
          <form onSubmit={this.handleOk}>
            <input
              ref={(element) => {
                this.valueRef = element
              }}
              type="text"
              className={classnames('regular', { error })}
              value={this.state.value}
              onChange={this.handleChange}
            />
            {this.props.optionOptions && (
              <div className="options">
                {this.props.optionText && <div>{this.props.optionText}:</div>}
                <select
                  value={this.state.optionValue}
                  title={this.props.optionTitle}
                  onChange={this.handleChangeOption}
                >
                  {this.props.optionOptions.map((option) => {
                    return (
                      <option key={option.value} value={option.value}>
                        {option.text}
                      </option>
                    )
                  })}
                </select>
              </div>
            )}
            {this.props.checkboxText && (
              <label title={this.props.checkboxTitle}>
                <input
                  type="checkbox"
                  checked={this.state.checkboxValue}
                  onChange={this.handleChangeCheckbox}
                />{' '}
                {this.props.checkboxText}
              </label>
            )}
          </form>
          {error && <div className="error-message">{error}</div>}
          <div className="modal-action-menu">
            <button
              className={classnames('modal-button', this.props.classCancel)}
              onClick={this.handleCancel}
            >
              {this.props.textCancel || 'Cancel'}
            </button>
            <button
              onClick={this.handleOk}
              className={classnames('modal-button', 'primary', this.props.classOk)}
            >
              {this.props.textOk || 'Ok'}
            </button>
          </div>
        </div>
      </Modal>
    )
  }

  componentDidMount() {
    // modal will become visible, set focus to the input value
    setTimeout(() => this.valueRef.select(), 0)
  }

  handleOk(event) {
    event.preventDefault() // stop form submit

    if (this.props.validate) {
      const error = this.props.validate(this.state.value)

      if (error != null) {
        // cancel the Ok action
        this.setState({ showValidationResult: true })
        this.valueRef.select()
        return
      }
    }

    this.close()

    if (this.props.onOk) {
      this.props.onOk(this.state.value, this.state.optionValue, this.state.checkboxValue)
    }
  }

  handleCancel() {
    this.close()

    if (this.props.onCancel) {
      this.props.onCancel()
    }
  }

  handleChange() {
    this.setState({
      value: this.valueRef.value
    })
  }

  handleChangeOption(event) {
    const optionValue = event.target.value

    this.setState({ optionValue })

    if (this.props.optionChange) {
      this.props.optionChange(optionValue)
    }
  }

  handleChangeCheckbox(event) {
    const checkboxValue = event.target.checked

    this.setState({ checkboxValue })

    if (this.props.checkboxChange) {
      this.props.checkboxChange(checkboxValue)
    }
  }

  close() {
    this.modalRef.close()
    this.props.onClose()
  }
}

/**
 * Show a modal prompt
 * @deprecated Use <Prompt /> instead of prompt(...)
 * @param {Object} props    Object with parameters. Available parameters:
 * @property {string | React.Component} title
 * @property {string | React.Component} text
 * @property {string | null} value
 * @property {function} onOk
 * @property {function} [onCancel]
 * @property {function (value: string) : string | null} [validate]
 * @property {string} [className]
 * @property {string} [textOk]     'Ok' by default.
 * @property {string} [textCancel] 'Cancel' by default.
 * @property {string} [classOk]    'primary' by default.
 * @property {string} [classCancel] null by default.
 */
export default function prompt(props) {
  const container = document.createElement('div')
  document.body.appendChild(container)

  function handleClose() {
    document.body.removeChild(container)
  }

  createRoot(container).render(<Prompt {...props} onClose={handleClose} />)
}
