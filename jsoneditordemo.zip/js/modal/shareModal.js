import React from 'react'
import Modal from './modal'
import './shareModal.scss'
import { createSharableUrl, isCloudDocument, isLocalDocument } from '../utils/documentUtils'
import CopyToClipboardButton from '../controls/CopyToClipboardButton'
import { createRoot } from 'react-dom/client'

function ShareModal({ document, compoundKey, onClose }) {
  const name = document.name ? `document "${document.name}"` : ''

  return (
    <Modal onRequestClose={onClose} className="share">
      <div className="modal modal-share">
        <h1>Share {name}</h1>
        {renderUrl(compoundKey)}
        <div className="modal-action-menu">
          <button className="modal-button" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </Modal>
  )
}

/**
 * @param {CompoundKey} compoundKey
 */
function renderUrl(compoundKey) {
  if (isLocalDocument(compoundKey)) {
    return (
      <div>
        <p>This document is stored locally in your browser and cannot be shared.</p>
        <p>
          To share this document, save it in the cloud first via menu &quot;Save&quot;, &quot;Save
          to cloud&quot;.
        </p>
      </div>
    )
  }

  if (isCloudDocument(compoundKey)) {
    const url = createSharableUrl(compoundKey)

    return (
      <div className="share-contents">
        <input readOnly value={url} className="url-contents" />
        <CopyToClipboardButton
          data={url}
          title="Copy url to clipboard"
          copiedText="Copied!"
          className="modal-button primary"
        />
      </div>
    )
  }

  return <div>Cannot create a sharable url. Please save the document in the cloud first.</div>
}

/**
 * Show a modal with sharing options
 * @param {Object} props    Object with parameters. Available parameters:
 * @property {Document} document
 * @property {CompoundKey} compoundKey
 */
export default function shareModal(props) {
  const container = document.createElement('div')
  document.body.appendChild(container)

  function handleClose() {
    document.body.removeChild(container)
  }

  createRoot(container).render(<ShareModal {...props} onClose={handleClose} />)
}
