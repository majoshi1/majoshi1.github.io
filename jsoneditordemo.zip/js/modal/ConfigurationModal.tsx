import classnames from 'classnames'
import React, { useEffect, useRef, useState } from 'react'
import StyledReactTooltip from '../controls/StyledReactTooltip'
import Modal from './modal.js'
import './ConfigurationModal.scss'
import { ParserId } from '../enums'
import type { Configuration } from '../types'
import { isValidFontSize, normalizeFontSize } from '../utils/fontUtils'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faInfoCircle } from '@fortawesome/free-solid-svg-icons'
import createDebug from 'debug'
import JSONEditorComponent from '../JSONEditorComponent'
import { getJSONParser } from '../utils/getJSONParser'
import { tryFormatContent } from '../utils/documentUtils'
import { LARGE_DOCUMENT_SIZE } from '../constants.js'
import { formatSize } from '../utils/fileUtils'
import type { Content } from 'svelte-jsoneditor'

const debug = createDebug('jsoneditoronline:ConfigurationModal')

const previewContent: Content = {
  text: `{
  "text": "Preview configuration settings",
  "boolean": true,
  "color": "red",
  "unicode": "😀",
  "multiline": "line1,\\nline2,\\nline3",
  "number": 4.0,
  "long": 18800000000000000123
}
`
}

const previewArrayContent: Content = {
  json: [
    {
      id: 1017,
      name: 'Joe',
      address: {
        city: 'New York',
        street: 'Victor Plains'
      },
      scores: [8.0, 7.2, 6.7]
    },
    {
      id: 1029,
      name: 'Sarah',
      address: {
        city: 'Manhattan',
        street: 'Skiles Walks'
      },
      scores: [6.1, 6.2, 6.0]
    },
    {
      id: 1022,
      name: 'Mike',
      address: {
        city: 'South Christy',
        street: 'Norberto Crossing'
      },
      scores: [7.1, 7.2]
    }
  ]
}

interface IndentationModalProps {
  config: Configuration
  onOk: (updatedConfig: Configuration) => void
  onClose: () => void
}

interface ValidationErrors {
  fontSize: string | undefined
  indentation: string | undefined
}

export default function ConfigurationModal({ config, onClose, onOk }: IndentationModalProps) {
  const modalRef = useRef<Modal>(null)
  const fontSizeRef = useRef<HTMLInputElement>(null)
  const previewContainerRef = useRef<HTMLInputElement>(null)
  const [previewMode, setPreviewMode] = useState('tree')
  const [fontSize, setFontSize] = useState(config.fontSize)
  const [useTab, setUseTab] = useState<boolean>(config.indentation === '\t') // if true, use tab, otherwise use spaces
  const [indentationValue, setIndentationValue] = useState<string>(
    config.indentation === '\t'
      ? String(config.tabSize)
      : typeof config.indentation === 'number'
      ? String(config.indentation) // for example 4
      : String(config.indentation.length) // for example '    '. This notation is not used, but just in case...
  )
  const [escapeControlCharacters, setEscapeControlCharacters] = useState(
    config.escapeControlCharacters
  )
  const [escapeUnicodeCharacters, setEscapeUnicodeCharacters] = useState(
    config.escapeUnicodeCharacters
  )
  const [flattenColumns, setFlattenColumns] = useState(config.flattenColumns)
  const [parserId, setParserId] = useState(config.parserId)
  const [validate, setValidate] = useState(false)
  const [content, setContent] = useState(previewContent)

  const indentationNumber = Number(indentationValue)
  const indentation = useTab ? '\t' : indentationNumber
  const tabSize = indentationNumber
  const updatedConfig = {
    fontSize: normalizeFontSize(fontSize),
    indentation,
    tabSize,
    escapeControlCharacters,
    escapeUnicodeCharacters,
    flattenColumns,
    parserId
  }
  const validationErrors = validate ? validateConfig(updatedConfig, indentationValue) : undefined
  const parser = getJSONParser(parserId, content)

  useEffect(() => {
    if (fontSizeRef.current) {
      fontSizeRef.current.select()
    }
  }, [])

  function applyFontSize(newFontSize: string) {
    setFontSize(newFontSize)

    if (previewContainerRef.current) {
      previewContainerRef.current.style.setProperty(
        '--jse-font-size-mono',
        getPreviewFontSize(normalizeFontSize(newFontSize), config.fontSize)
      )
    }
  }

  function applyFormatting(newUseTab: boolean, newIndentationValue: string) {
    const newIndentation = getPreviewIndentation(newUseTab, newIndentationValue, config.indentation)
    setContent(tryFormatContent(content, parser, newIndentation))
  }

  function applyPreviewMode(mode: string) {
    const activeElement = document.activeElement

    setPreviewMode(mode)

    if (mode === 'table') {
      setContent(previewArrayContent)
    } else {
      setContent(previewContent)
    }

    // after switching the Preview to text mode, the editor grabs focus, but we don't want that.
    setTimeout(() => {
      if (activeElement) {
        ;(activeElement as HTMLInputElement).focus()
      }
    })
  }

  function applyUseTab(newUseTab: boolean) {
    applyPreviewMode('text')
    setUseTab(newUseTab)
    applyFormatting(newUseTab, indentationValue)
  }

  function applyIndentationValue(newIndentationValue: string) {
    applyPreviewMode('text')
    setIndentationValue(newIndentationValue)
    applyFormatting(useTab, newIndentationValue)
  }

  function applyEscapeControlCharacters(newEscapeControlCharacters: boolean) {
    applyPreviewMode('tree')
    setEscapeControlCharacters(newEscapeControlCharacters)
  }

  function applyEscapeUnicodeCharacters(newEscapeUnicodeCharacters: boolean) {
    if (previewMode === 'table') {
      applyPreviewMode('tree')
    } else {
      setContent(previewContent)
    }
    setEscapeUnicodeCharacters(newEscapeUnicodeCharacters)
  }

  function applyFlattenColumns(newFlattenColumns: boolean) {
    applyPreviewMode('table')
    setFlattenColumns(newFlattenColumns)
  }

  function applyParserId(parserId: ParserId) {
    applyPreviewMode('tree')
    setParserId(parserId)
  }

  function handleOk(): boolean {
    setValidate(true)

    const hasValidationErrors = !!validateConfig(updatedConfig, indentationValue)
    if (hasValidationErrors) {
      return false
    }

    onOk(updatedConfig)

    close()

    return true
  }

  function handleCancel() {
    close()
  }

  function close() {
    if (modalRef.current) {
      modalRef.current.close()
    }

    onClose()
  }

  function handleSaveAndReload() {
    debug('save and reload')
    const closed = handleOk()
    if (closed) {
      window.location.reload()
    }
  }

  return (
    <Modal ref={modalRef} className="configuration" onRequestClose={handleCancel}>
      <div className="modal modal-configuration">
        <StyledReactTooltip />
        <h1>Configuration</h1>

        <div className="columns">
          <div className="column left">
            <form onSubmit={handleOk}>
              <h2>Font size</h2>
              <div className="modal-text">
                Configure the font size, for example <code>&quot;14px&quot;</code> (default) or{' '}
                <code>&quot;12pt&quot;</code>.
              </div>

              <table>
                <tbody>
                  <tr>
                    <td>Font size:</td>
                    <td>
                      <input
                        ref={fontSizeRef}
                        type="text"
                        value={fontSize}
                        onChange={(event) => applyFontSize(event.target.value)}
                        className={classnames('fontSize', 'regular', {
                          error: validationErrors?.fontSize
                        })}
                      />
                    </td>
                  </tr>
                </tbody>
              </table>
              {validationErrors?.fontSize && (
                <div className="error-message">{validationErrors.fontSize}</div>
              )}

              <h2>Indentation</h2>

              <div className="modal-text">
                Indentation used in text mode and when copying or saving a document.
              </div>
              <table>
                <tbody>
                  <tr>
                    <td>Type of indentation:</td>
                    <td className="indentation-types">
                      <label>
                        <input
                          type="radio"
                          name="useTab"
                          value="spaces"
                          checked={!useTab}
                          onChange={() => applyUseTab(false)}
                        />{' '}
                        Spaces
                      </label>
                      <label>
                        <input
                          type="radio"
                          name="useTab"
                          value="tabs"
                          checked={useTab}
                          onChange={() => applyUseTab(true)}
                        />{' '}
                        Tabs
                      </label>
                    </td>
                  </tr>
                  <tr>
                    <td>{useTab ? 'Tab size: ' : 'Number of spaces: '}</td>
                    <td>
                      <input
                        type="text"
                        className={classnames('indentation', 'regular', {
                          error: validationErrors?.indentation
                        })}
                        value={indentationValue}
                        onChange={(event) => applyIndentationValue(event.target.value)}
                      />
                    </td>
                  </tr>
                </tbody>
              </table>
              {validationErrors?.indentation && (
                <div className="error-message">{validationErrors.indentation}</div>
              )}

              <h2>Escape characters</h2>

              <table>
                <tbody>
                  <tr>
                    <td>
                      <label>
                        <input
                          type="checkbox"
                          checked={escapeControlCharacters}
                          onChange={(event) => applyEscapeControlCharacters(event.target.checked)}
                        />{' '}
                        Escape control characters like newline <code>&quot;\n&quot;</code> and tab{' '}
                        <code>&quot;\t&quot;</code>{' '}
                        <div
                          className="explanation"
                          data-tip="Escaping control characters is only applicable to tree mode."
                        >
                          <FontAwesomeIcon icon={faInfoCircle} />
                        </div>
                      </label>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <label>
                        <input
                          type="checkbox"
                          checked={escapeUnicodeCharacters}
                          onChange={(event) => applyEscapeUnicodeCharacters(event.target.checked)}
                        />{' '}
                        Escape unicode characters like smilies {'\uD83D\uDE01'}
                      </label>
                    </td>
                  </tr>
                </tbody>
              </table>

              <h2>Table view</h2>

              <label>
                <input
                  type="checkbox"
                  checked={flattenColumns}
                  onChange={(event) => applyFlattenColumns(event.target.checked)}
                />{' '}
                Flatten nested object properties into separate columns
              </label>

              <h2>Parser</h2>

              <div className="modal-text">Select a JSON parser:</div>

              <div>
                <label>
                  <input
                    type="radio"
                    name="parserId"
                    value="auto"
                    checked={parserId === ParserId.auto}
                    onChange={() => applyParserId(ParserId.auto)}
                  />{' '}
                  Auto select{' '}
                  <div
                    className="explanation"
                    data-tip={
                      `Selects the Lossless JSON Parser for documents up to ${formatSize(
                        LARGE_DOCUMENT_SIZE
                      )}, ` + ' and selects the fast Native JSON Parser for larger documents.'
                    }
                  >
                    <FontAwesomeIcon icon={faInfoCircle} />
                  </div>
                </label>
              </div>
              <div>
                <label>
                  <input
                    type="radio"
                    name="parserId"
                    value="native"
                    checked={parserId === ParserId.native}
                    onChange={() => applyParserId(ParserId.native)}
                  />{' '}
                  Native JSON Parser{' '}
                  <div
                    className="explanation"
                    data-tip="The Native JSON parser uses the browser's built-in JSON parser. This parser is very fast, but cannot handle long numbers."
                  >
                    <FontAwesomeIcon icon={faInfoCircle} />
                  </div>
                </label>
              </div>
              <div>
                <label>
                  <input
                    type="radio"
                    name="parserId"
                    value="lossless"
                    checked={parserId === ParserId.lossless}
                    onChange={() => applyParserId(ParserId.lossless)}
                  />{' '}
                  Lossless JSON Parser{' '}
                  <div
                    className="explanation"
                    data-tip={
                      'The Lossless JSON parser can handle long numbers and maintains the formatting of numbers. ' +
                      `The parser is slower than the Native JSON parser, which is noticeable for documents larger than ${formatSize(
                        LARGE_DOCUMENT_SIZE
                      )}.`
                    }
                  >
                    <FontAwesomeIcon icon={faInfoCircle} />
                  </div>
                </label>
              </div>

              {parserId !== config.parserId && (
                <div className="reload-warning">
                  <div className="reload-message">
                    The selected parser will be used after reloading the web application.
                  </div>
                  <div>
                    <button className="modal-button primary" onClick={handleSaveAndReload}>
                      Save config and reload now
                    </button>
                  </div>
                </div>
              )}
            </form>
          </div>
          <div className="column right">
            <h2>Preview</h2>

            <div className="preview-container" ref={previewContainerRef}>
              <JSONEditorComponent
                key={parserId}
                mode={previewMode}
                content={content}
                onChange={setContent}
                onChangeMode={setPreviewMode}
                flattenColumns={flattenColumns}
                parser={parser}
                indentation={getPreviewIndentation(useTab, indentationValue, config.indentation)}
                tabSize={getPreviewTabSize(indentationValue, config.tabSize)}
                escapeControlCharacters={escapeControlCharacters}
                escapeUnicodeCharacters={escapeUnicodeCharacters}
              />
            </div>
          </div>
        </div>

        <div className="modal-action-menu">
          <button className="modal-button" onClick={handleCancel}>
            Cancel
          </button>
          <button className="modal-button primary" onClick={handleOk}>
            Ok
          </button>
        </div>
      </div>
    </Modal>
  )
}

function isValidIndentationValue(value: string | number) {
  return isPositiveIntegerNumber(Number(value))
}

function isPositiveIntegerNumber(value: number): boolean {
  return !isNaN(value) && isFinite(value) && value > 0 && Math.round(value) === value
}

function getPreviewIndentation(
  useTab: boolean,
  indentationValue: string,
  defaultIndentation: string | number
): string | number {
  const indentationNumber = Number(indentationValue)

  return useTab
    ? '\t'
    : isValidIndentationValue(indentationNumber)
    ? indentationNumber
    : defaultIndentation // fallback on the default
}

function getPreviewTabSize(indentationValue: string, defaultTabSize: number): number {
  const indentationNumber = Number(indentationValue)

  return isValidIndentationValue(indentationNumber) ? indentationNumber : defaultTabSize // fallback on the default
}

function getPreviewFontSize(fontSize: string, defaultFontSize: string): string {
  return isValidFontSize(fontSize) ? fontSize : defaultFontSize
}

function validateConfig(
  configuration: Configuration,
  indentationValue: string
): ValidationErrors | undefined {
  const errors: ValidationErrors = {
    fontSize: undefined,
    indentation: undefined
  }

  // validate fontSize input field
  if (!isValidFontSize(configuration.fontSize)) {
    errors.fontSize =
      'Error: invalid font size. ' +
      'Must be an integer number between 10 and 99 with an optional suffix "px" or "pt".'
  }

  // validate indentation input field
  if (!isValidIndentationValue(indentationValue)) {
    errors.indentation = 'Error: value must be a positive integer number'
  }

  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  return Object.keys(errors).some((key) => errors[key] !== undefined) ? errors : undefined
}
