import React from 'react'
import './index.scss'
import App from './App.js'
import * as serviceWorkerRegistration from './serviceWorkerRegistration.js'
import createDebug from 'debug'
import { createRoot } from 'react-dom/client'

const debug = createDebug('jsoneditoronline:index')

console.info(
  'To see logging output in the console, ' +
    'set localStorage.debug and refresh the page. ' +
    'For example: localStorage.debug="jsoneditoronline:*"'
)
console.info('Current value of localStorage.debug:', window.localStorage.debug)

// backward compatibility with the old web application.
// Examples:
//   https://jsoneditoronline.org/?id=4deb0f3c66c744d495f777a2d65d37f9
//   https://jsoneditoronline.org/?json=[1,2,3]
//   https://jsoneditoronline.org/?url=https://jsoneditoronline.herokuapp.com/v1/docs/4deb0f3c66c744d495f777a2d65d37f9/data
const match = /\?(id|url|json)=(.+)/.exec(window.location.search)
if (match) {
  const key = match[1]
  const documentId = match[2]
  const documentSource = key === 'id' ? 'cloud' : key // 'json' or 'url'

  debug('Change legacy url search parameters into hash parameters')
  window.location.href = `${window.location.origin}/#left=${documentSource}.${documentId}`
}

createRoot(document.getElementById('root')).render(<App />)

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://cra.link/PWA
serviceWorkerRegistration.register()
