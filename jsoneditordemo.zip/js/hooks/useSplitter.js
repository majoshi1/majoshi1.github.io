import { useEffect } from 'react'
import createDebug from 'debug'

const debug = createDebug('jsoneditoronline:useSplitter')

export default function useSplitter({ setSplitterValue, refContainer, refSplitter }) {
  useEffect(() => {
    if (!refSplitter || !refSplitter.current || !refContainer || !refContainer.current) {
      return
    }

    const refContainerCurrent = refContainer.current
    const refSplitterCurrent = refSplitter.current

    const dragState = {
      startMouseX: null,
      startSplitterX: null,
      offsetX: null
    }

    function handleMouseDown(event) {
      event.preventDefault()

      const rectContainer = refContainerCurrent.getBoundingClientRect()
      const rectSplitter = refSplitterCurrent.getBoundingClientRect()

      dragState.startMouseX = event.clientX
      dragState.startSplitterX = rectSplitter.left
      dragState.offsetX = dragState.startSplitterX - dragState.startMouseX

      debug('pointer down', event.clientX)

      function handleMouseMove(event) {
        event.preventDefault()

        const splitterX = event.clientX + dragState.offsetX
        const width = rectContainer.width - rectSplitter.width
        const newValue = width > 0 ? (splitterX - rectContainer.left) / width : 0.5 // safety fallback, should not happen

        // debug('pointer move', { splitterX, width, newValue })

        setSplitterValue(newValue)
      }

      function handleMouseUp(event) {
        event.preventDefault()

        document.body.removeEventListener('pointermove', handleMouseMove)
        document.body.removeEventListener('pointerup', handleMouseUp)

        debug('pointer up')
      }

      document.body.addEventListener('pointermove', handleMouseMove)
      document.body.addEventListener('pointerup', handleMouseUp)
    }

    refSplitterCurrent.addEventListener('pointerdown', handleMouseDown)
    // debug('addEventListener to splitter ref')

    return () => {
      refSplitterCurrent.removeEventListener('pointerdown', handleMouseDown)
      // debug('removeEventListener from splitter ref')
    }
  }, [refContainer, refSplitter, setSplitterValue])
}
