import createDebug from 'debug'
import { useEffect, useState } from 'react'

const debug = createDebug('jsoneditoronline:useSystemTheme')

/**
 * Get the current system theme and listen for changes
 * @returns {'light' | 'dark'}
 */
export default function useSystemTheme() {
  const [darkThemeMediaQuery] = useState(window.matchMedia('(prefers-color-scheme: dark)'))

  const [systemTheme, setSystemTheme] = useState(() => {
    const initialTheme = getThemeFromQuery(darkThemeMediaQuery)
    debug(`Initial system theme: ${initialTheme}`)
    return initialTheme
  })

  useEffect(() => {
    function onChangeTheme(event) {
      const newTheme = getThemeFromQuery(event)

      if (newTheme !== systemTheme) {
        debug(`System theme changed from ${systemTheme} to ${newTheme}`)
        setSystemTheme(newTheme)
      }
    }

    darkThemeMediaQuery.addEventListener('change', onChangeTheme)

    return () => {
      darkThemeMediaQuery.removeEventListener('change', onChangeTheme)
    }
  })

  return systemTheme
}

function getThemeFromQuery(query) {
  return query.matches ? 'dark' : 'light'
}
