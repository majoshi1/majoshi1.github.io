import { useCallback, useEffect, useRef } from 'react'

/**
 * Source of inspiration: https://github.com/ardsh/use-cancelable-timeout
 */
export default function useTimeout() {
  const timerRef = useRef(null)

  const clearTimeout = useCallback(function () {
    if (timerRef.current != null) {
      window.clearTimeout(timerRef.current)
      timerRef.current = null
    }
  }, [])

  const setTimeout = useCallback(function (callback, delay) {
    // first clear any previous timer
    if (timerRef.current != null) {
      window.clearTimeout(timerRef.current)
    }

    timerRef.current = window.setTimeout(callback, delay)
  }, [])

  useEffect(() => {
    return () => {
      clearTimeout()
    }
  }, [clearTimeout])

  return [setTimeout, clearTimeout]
}
