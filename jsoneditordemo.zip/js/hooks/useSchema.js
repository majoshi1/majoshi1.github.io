import createDebug from 'debug'
import { useEffect } from 'react'
import { useAsync } from 'react-async-hook'
import { createAjvValidator } from 'vanilla-jsoneditor'
import { loadUrl } from '../rest'
import { loadDocument, parseContent } from '../utils/documentUtils'

const debug = createDebug('jsoneditoronline:useSchema')

const DEFAULT_SCHEMA = { type: 'NONE', leftPanel: false, rightPanel: false }

/**
 * Hook to load a schema
 * @param {SchemaConfig} schemaConfig
 * @param {string} panelId
 * @param {Array.<{panelId: string, compoundKey: string, document: Document}>} allPanels
 * @property {Content} leftPanelContent
 * @property {Content} rightPanelContent
 */
export default function useSchema(schemaConfig, panelId, allPanels) {
  if (!schemaConfig) {
    schemaConfig = DEFAULT_SCHEMA
  }

  const schemaFromId = useAsync(loadDocument, [schemaConfig.compoundKey])
  const schemaParser = JSON // we use the native parser here, LossessJSON is not supported anyway by Ajv

  const url = schemaConfig.type === 'URL' ? schemaConfig.url : null
  const schemaFromUrl = useAsync(loadUrl, [url])
  // TODO: should not invoke loadUrl when url is null (loadUrl now has a workaround for this, but it is ugly)

  useEffect(() => {
    debug('schema config changed', { schemaConfig })
  }, [schemaConfig])

  if (schemaConfig) {
    try {
      if (schemaConfig.type === 'TEXT') {
        return {
          loading: false,
          error: null,
          content: validateContent(parseContent(schemaConfig.content, schemaParser))
        }
      }

      if (schemaConfig.type === 'DOCUMENT') {
        return {
          loading: schemaFromId.status === 'loading',
          error: schemaFromId.error,
          content:
            schemaFromId.result && schemaFromId.status !== 'loading'
              ? validateContent(parseContent(schemaFromId.result.content, schemaParser))
              : null
        }
      }

      if (schemaConfig.type === 'URL') {
        return {
          loading: schemaFromUrl.status === 'loading',
          error: schemaFromUrl.error,
          content: schemaFromUrl.status !== 'loading' ? validateContent(schemaFromUrl.result) : null
        }
      }

      if (schemaConfig.type === 'PANEL') {
        if (schemaConfig.panelId === panelId) {
          return {
            loading: false,
            error: 'Error: Cannot select panel itself as JSON schema.',
            content: null
          }
        }

        const panel = allPanels.find((panel) => panel.panelId === schemaConfig.panelId)

        if (!panel) {
          return {
            loading: false,
            error: `Error: Panel with id "${schemaConfig.panelId}" not found.`,
            content: null
          }
        }

        return {
          loading: false,
          error: null,
          content: validateContent(parseContent(panel.document.content, schemaParser))
        }
      }
    } catch (err) {
      return {
        loading: false,
        error: err.toString(),
        content: null
      }
    }
  }

  return {
    loading: false,
    error: null,
    content: null
  }
}

// try to compile, this will fail and throw an exception when the schema is invalid
function validateContent(schema) {
  if (schema) {
    createAjvValidator({ schema })
  }

  return schema
}
