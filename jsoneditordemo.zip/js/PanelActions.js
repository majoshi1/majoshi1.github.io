import { faSquare } from '@fortawesome/free-regular-svg-icons'
import {
  faCheckSquare,
  faChevronDown,
  faChevronLeft,
  faChevronRight,
  faChevronUp
} from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React from 'react'
import './PanelActions.scss'

export default function PanelActions({
  copyLeftToRight,
  copyRightToLeft,
  transformLeftToRight,
  transformRightToLeft,
  toggleDiff,
  showDiff,
  diff,
  diffChangeCount,
  diffChangeIndex,
  toPreviousDiff,
  toNextDiff
}) {
  return (
    <div className="panel-actions">
      <div className="action-group">
        <div className="action-group-name">Copy</div>
        <div className="action-buttons">
          <button
            onClick={copyRightToLeft}
            title="Copy the contents of the right panel to the left panel"
          >
            <FontAwesomeIcon icon={faChevronLeft} />
          </button>
          <button
            onClick={copyLeftToRight}
            title="Copy the contents of the left panel to the right panel"
          >
            <FontAwesomeIcon icon={faChevronRight} />
          </button>
        </div>
      </div>

      <div className="action-group">
        <div className="action-group-name">Transform</div>
        <div className="action-buttons">
          <button
            onClick={transformRightToLeft}
            title="Transform the contents of the right panel into the left panel"
          >
            <FontAwesomeIcon icon={faChevronLeft} />
          </button>
          <button
            onClick={transformLeftToRight}
            title="Transform the contents of the left panel into the right panel"
          >
            <FontAwesomeIcon icon={faChevronRight} />
          </button>
        </div>
      </div>

      <div className="action-group">
        <div className="action-group-name">Differences</div>
        <button
          onClick={toggleDiff}
          title={`Highlight the differences between left and right panel contents (currently ${
            showDiff ? 'enabled' : 'disabled'
          })`}
        >
          <FontAwesomeIcon icon={showDiff ? faCheckSquare : faSquare} /> Compare
        </button>
        {showDiff && diffChangeCount !== undefined && (
          <div className="diff-form-contents">
            {!diff.error ? (
              <>
                <div className="diff-counter">
                  {(diffChangeIndex >= 0 ? diffChangeIndex + 1 + '/' : '') +
                    (diffChangeCount + ' difference') +
                    (diffChangeCount !== 1 ? 's' : '')}
                </div>
                <div className="action-buttons">
                  <button onClick={toPreviousDiff} title="Go to previous difference">
                    <FontAwesomeIcon icon={faChevronUp} />
                  </button>
                  <button onClick={toNextDiff} title="Go to next difference">
                    <FontAwesomeIcon icon={faChevronDown} />
                  </button>
                </div>
              </>
            ) : (
              <div className="diff-error" title={diff.error.toString()}>
                Diff: Error
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
