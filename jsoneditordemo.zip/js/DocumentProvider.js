import createDebug from 'debug'
import { debounce, last } from 'lodash'
import PropTypes from 'prop-types'
import { PureComponent } from 'react'
import { isLargeContent } from 'svelte-jsoneditor' // do not use vanilla-jsoneditor to allow code splitting
import { DocumentSource, Formatting, MAX_LOCAL_DOCUMENT_SIZE } from './constants'
import { addRecentFile, removeRecentFile } from './recentFiles'
import {
  createCloudDocument,
  deleteCloudDocument,
  loadCloudDocument,
  saveCloudDocument
} from './rest'
import { isoDateNow } from './utils/dateUtils'
import {
  hasDocumentSource,
  isCloudDocument,
  isLocalDocument,
  splitCompoundKey,
  stringifyContent
} from './utils/documentUtils'
import { createError } from './utils/errorUtils'
import {
  addExtensionIfNeeded,
  formatSize,
  removeFileExtension,
  saveFileViaAnchor
} from './utils/fileUtils'
import { getFriendlyId } from './utils/friendlyId'
import { createHash } from './utils/hashUtils'
import {
  createNewDocumentName,
  deleteLocalDocument,
  loadLocalDocument,
  saveLocalDocument
} from './utils/indexedDbUtils'
import { loadFromLocalStorage, saveToLocalStorage } from './utils/localStorageUtils'
import { notifyBusy, notifyError, notifySuccess } from './utils/modalUtils'
import { wait } from './utils/timeUtils'
import { getJSONParser } from './utils/getJSONParser'
import { ParserId } from './enums'

const debug = createDebug('jsoneditoronline:DocumentProvider')

const PERSIST_LOCAL_STORAGE_DELAY = 1000 // ms
const PERSIST_CLOUD_DELAY = 4000 // ms
const FIRST_TIME_USE_KEY = 'firstTimeUse'

const DEFAULT_CONTENT = {
  json: {
    array: [1, 2, 3],
    boolean: true,
    color: 'gold',
    null: null,
    number: 123,
    object: { a: 'b', c: 'd' },
    string: 'Hello World'
  }
}

const DEFAULT_SCHEMA = {
  type: 'NONE',
  url: null,
  id: null,
  content: null,
  leftPanel: false,
  rightPanel: false
}

// FIXME: reimplement showing a DEFAULT_DOCUMENT for first time users
const DEFAULT_DOCUMENT = {
  _id: undefined,
  name: undefined,
  content: DEFAULT_CONTENT,
  schema: DEFAULT_SCHEMA,
  updated: undefined
}

const EMPTY_DOCUMENT = {
  _id: undefined,
  name: undefined,
  content: {
    text: ''
  },
  schema: DEFAULT_SCHEMA,
  updated: undefined
}

// TODO: rewrite to react hook
export default class DocumentProvider extends PureComponent {
  constructor(props) {
    super(props)

    debug('loading parserId', props.parserId)

    const document = EMPTY_DOCUMENT
    const parser = getJSONParser(props.parserId, document.content)

    /**
     * @type {Object}
     * @property {number} documentSequenceNr
     * @property {CompoundKey | null} compoundKey
     * @property {Document | null} document
     * @property {ParserId} parserId
     * @property {JSONParser} parser
     * @property {boolean} unsavedChanges
     * @property {boolean} loading
     * @property {Error | null} loadingError
     * @property {Error | null} localStorageError
     */
    this.state = {
      documentSequenceNr: 1,
      document,
      parserId: props.parserId,
      parser,
      compoundKey: null,
      unsavedChanges: false,
      loading: true,
      loadingError: null,
      localStorageError: null
    }

    this.hash = createHash()
    this.hash.onChange(props.hashKey, (compoundKey) => {
      debug('hash.onChange', { key: props.hashKey, compoundKey })

      // replace undefined with null
      const newCompoundKey = compoundKey === undefined ? null : compoundKey

      if (newCompoundKey !== this.state.compoundKey) {
        debug('compoundKey changed')
        this.loadDocument(compoundKey)
      }
    })

    this._debouncedSaveToLocalStorage = debounce(this.saveChanges, PERSIST_LOCAL_STORAGE_DELAY)
    this._debouncedSaveToCloud = debounce(this.saveChanges, PERSIST_CLOUD_DELAY)
  }

  componentDidMount() {
    const compoundKey = this.hash.getValue(this.props.hashKey)
    this.loadDocument(compoundKey)
  }

  componentWillUnmount() {
    this.hash.destroy()
    this.hash = null
  }

  /**
   * React 18 has automatic batching, and because of that, after executing
   * `await this.setState(...)`, the `this.state` is NOT yet updated.
   * Therefore, we introduce an `await wait(0)` which will rerender the app and then continue
   */
  async setStateAsync(state) {
    await this.setState(state)
    await wait(0)
    await wait(0)
    // FIXME: relaying on a couple of wait(0) is really an unreliable disaster, fix this.
    //  Note: the second wait was added after code-splitting and suspense was introduced.
  }

  render() {
    const { loading, document, loadingError, unsavedChanges, localStorageError } = this.state

    return this.props.children
      ? this.props.children({
          documentSequenceNr: this.state.documentSequenceNr,
          loading,
          document,
          compoundKey: this.state.compoundKey,
          parserId: this.state.parserId,
          parser: this.state.parser,
          unsavedChanges,
          error: loadingError,
          localStorageError,
          newDocument: this.newDocument.bind(this),
          updateDocument: this.updateDocument.bind(this),
          updateDocumentProperties: this.updateDocumentProperties.bind(this),
          renameDocument: this.renameDocument.bind(this),
          loadDocument: this.loadDocument.bind(this),
          loadFromCloud: this.loadFromCloud.bind(this),
          loadFromUrl: this.loadFromUrl.bind(this),
          loadFromDisk: this.loadFromDisk.bind(this),
          saveToCloud: this.saveToCloud.bind(this),
          saveToDisk: this.saveToDisk.bind(this),
          saveToUrl: this.saveToUrl.bind(this),
          saveChanges: this.saveChanges.bind(this),
          deleteDocument: this.deleteDocument.bind(this)
        })
      : null
  }

  async loadDocument(compoundKey) {
    if (!compoundKey) {
      // load new, empty document (or the default document when it's the first time)

      const firstTimeUse = this.props.loadDefaultDocumentOnFirstUse
        ? loadFromLocalStorage(FIRST_TIME_USE_KEY) !== false
        : false

      await this.setStateAsync({
        documentSequenceNr: this.state.documentSequenceNr + 1,
        compoundKey: null,
        document: firstTimeUse ? loadLegacyOrDefault() : EMPTY_DOCUMENT,
        loading: false,
        loadingError: null
      })

      this.hash.removeValue(this.props.hashKey)

      return
    }

    if (!hasDocumentSource(compoundKey)) {
      await this.setStateAsync({
        loading: false,
        loadingError: new Error(
          `Cannot load document with id "${compoundKey}",` +
            ' expecting a compound key "local.id" or "cloud.id".'
        )
      })

      return
    }

    const { documentSource } = splitCompoundKey(compoundKey)
    switch (documentSource) {
      case DocumentSource.CLOUD:
        debug(`load from cloud: ${compoundKey}`)
        await this.loadFromCloud(compoundKey, { silent: true })
        return

      case DocumentSource.LOCAL:
        debug(`load locally: ${compoundKey}`)
        await this.loadLocally(compoundKey, { silent: true })
        return

      case DocumentSource.JSON:
        debug(`load json: ${compoundKey}`)
        await this.loadFromJson(compoundKey)
        return

      case DocumentSource.URL:
        debug(`load url: ${compoundKey}`)
        await this.loadFromUrl(compoundKey)
        return

      default:
        await this.setErroredDocument(
          new Error(
            `Cannot load document with id "${compoundKey}",` +
              ` unknown document source "${documentSource}".` +
              ' Known sources: "local", "cloud", "url", or "json".'
          ),
          true
        )
    }
  }

  async newDocument() {
    const document = _updateDocument({
      content: { text: '' }
    })
    debug('newDocument', { document })

    const parser = getJSONParser(this.state.parserId, document.content)

    await this.setStateAsync({
      documentSequenceNr: this.state.documentSequenceNr + 1,
      compoundKey: null,
      document,
      parser,
      loadingError: false,
      localStorageError: null,
      unsavedChanges: false
    })

    debug('newDocument', {
      hashKey: this.props.hashKey,
      document,
      stateDocument: this.state.document,
      parserId: this.state.parserId,
      parser: parser === JSON ? ParserId.native : ParserId.lossless
    })

    this.hash.removeValue(this.props.hashKey)

    if (this.props.loadDefaultDocumentOnFirstUse) {
      saveToLocalStorage(FIRST_TIME_USE_KEY, false)
    }
  }

  async updateDocument(document, saveImmediately = false) {
    const updatedDocument = _updateDocument(document)

    await this.setStateAsync({
      document: updatedDocument,
      unsavedChanges: true
    })

    if (saveImmediately) {
      this.saveChanges()
    } else {
      this.debouncedSaveChanges()
    }

    return updatedDocument
  }

  async renameDocument(name) {
    await this.updateDocumentProperties({ name })
    await this.saveChanges()
  }

  async updateDocumentProperties(properties, saveImmediately = false) {
    const document = _updateDocument(this.state.document, properties)

    await this.setStateAsync({
      document,
      loadingError: null,
      unsavedChanges: true
    })

    if (saveImmediately) {
      this.saveChanges()
    } else {
      this.debouncedSaveChanges()
    }

    return document
  }

  async loadLocally(compoundKey, { silent } = { silent: false }) {
    await this.setLoading()

    try {
      const { documentId } = splitCompoundKey(compoundKey)
      const document = await loadLocalDocument(documentId)
      if (document) {
        await this.setLoadedDocument(document, compoundKey, silent)
      } else {
        await this.setErroredDocument(
          createError({
            message: `Local document with id "${compoundKey}" not found`,
            reasons: [
              'Did you delete this local document?',
              'Did you save this local document in the cloud instead?',
              'Did you clean offline storage of your browser recently?',
              'Did someone share a url of a local document located on his/her browser and not yours?'
            ]
          }),
          silent
        )
      }
    } catch (err) {
      await this.setErroredDocument(err, silent)
    }
  }

  async saveLocally({ silent } = { silent: false }) {
    debug(`save document locally (_id: ${this.state.document._id})`)

    const notification = !silent ? notifyBusy('Saving document...') : null

    if (isLargeContent(this.state.document.content, MAX_LOCAL_DOCUMENT_SIZE)) {
      await this.setStateAsync({
        unsavedChanges: false,
        localStorageError:
          'The JSON document is too large to store locally in your browser,' +
          ' and will be lost when closing the browser.' +
          ' Make sure you save the document yourself.' +
          ` Maximum size: ${formatSize(MAX_LOCAL_DOCUMENT_SIZE)}.`
      })

      return
    }

    try {
      if (this.state.document._id) {
        const compoundKey = `local.${this.state.document._id}`
        await saveLocalDocument(
          this.state.document._id,
          this.state.document,
          this.state.parser,
          this.props.indentation
        )
        addRecentFile(compoundKey, this.state.document)

        debug('Updated existing local document')
      } else {
        const _id = getFriendlyId()
        const compoundKey = `local.${_id}`
        const name = this.state.document.name || (await createNewDocumentName())
        const updatedDocument = _updateDocument(this.state.document, { _id, name })

        await this.setStateAsync({
          compoundKey,
          document: updatedDocument
        })
        this.updateHash()

        await saveLocalDocument(_id, updatedDocument, this.state.parser, this.props.indentation)
        addRecentFile(compoundKey, updatedDocument)

        debug('Saved new local document', _id)
      }

      await this.setStateAsync({
        unsavedChanges: false,
        localStorageError: null
      })

      if (!silent) {
        notifySuccess(`Document "${this.state.document.name}" saved locally.`)
      }
    } catch (err) {
      await this.setStateAsync({
        unsavedChanges: false,
        localStorageError: err.toString()
      })
    } finally {
      if (notification) {
        notification.close()
      }
    }
  }

  async saveChanges({ silent, force } = { silent: true, force: false }) {
    if (this.state.unsavedChanges || force) {
      try {
        const { documentSource } = splitCompoundKey(this.state.compoundKey)
        switch (documentSource) {
          case DocumentSource.CLOUD:
            await this.saveToCloud({ silent })
            break

          case DocumentSource.LOCAL:
          case DocumentSource.URL:
          case DocumentSource.JSON:
          case null:
            await this.saveLocally({ silent })
            break

          default:
            throw new Error(
              'Cannot save changes, ' +
                `unknown document source "${documentSource}". ` +
                ' Known sources: "local", "cloud", "url", or "json".'
            )
        }
      } catch (err) {
        console.error(err)
        notifyError(err)
      }
    }

    if (this.props.loadDefaultDocumentOnFirstUse) {
      saveToLocalStorage(FIRST_TIME_USE_KEY, false)
    }
  }

  debouncedSaveChanges() {
    if (isCloudDocument(this.state.compoundKey)) {
      this._debouncedSaveToCloud()
    } else {
      this._debouncedSaveToLocalStorage()
    }
  }

  async loadFromCloud(compoundKey, { silent } = { silent: false }) {
    const notification = !silent ? notifyBusy('Loading document...') : null

    await this.setLoading()

    try {
      const { documentId } = splitCompoundKey(compoundKey)
      debug(`Load document with id ${documentId}...`)
      const document = await loadCloudDocument(documentId)

      if (!document.content) {
        console.error(
          'Document loaded from cloud is missing a content object. Inserting an empty content object'
        )
        document.content = {
          text: ''
        }
      }

      await this.setLoadedDocument(document, compoundKey, silent)
      debug('Loaded document', document)
    } catch (error) {
      await this.setErroredDocument(error, silent)
    } finally {
      if (notification) {
        notification.close()
      }
    }

    return this.state.document
  }

  async saveToCloud({ silent } = { silent: false }) {
    const name = this.state.document.name
    debug(`save document to cloud (hashKey: ${this.props.hashKey}, name: ${name})`)

    const notification = !silent ? notifyBusy('Saving document...') : null

    try {
      if (isCloudDocument(this.state.compoundKey)) {
        await saveCloudDocument(this.state.document, this.state.parser, this.props.indentation)
        addRecentFile(this.state.compoundKey, this.state.document)

        debug('Updated existing document')
      } else {
        const localId = this.state.document._id
        const documentWithoutId = {
          ...this.state.document,
          _id: undefined
        }

        const { id } = await createCloudDocument(documentWithoutId, this.state.parser)
        const compoundKey = `cloud.${id}`
        await this.updateDocumentProperties({ _id: id })
        await this.setStateAsync({ compoundKey })
        this.updateHash()

        // in case of a new document, we want to remove the local version of the document
        // to prevent having two versions of the same document lying around
        if (localId) {
          removeRecentFile(`local.${localId}`)
          await deleteLocalDocument(localId)
        }

        addRecentFile(compoundKey, this.state.document)

        debug('Saved new document', id, name)
      }

      await this.setStateAsync({ unsavedChanges: false })

      if (!silent) {
        notifySuccess(`Document "${name}" saved.`)
      }
    } catch (err) {
      console.error(err)
      notifyError(err)
    } finally {
      if (notification) {
        notification.close()
      }
    }

    return this.state.document
  }

  /**
   * @param {CompoundKey} compoundKey
   */
  async deleteDocument(compoundKey) {
    debug('deleteDocument', compoundKey)

    try {
      await this.setStateAsync({ unsavedChanges: false })

      const { documentSource, documentId } = splitCompoundKey(compoundKey)
      switch (documentSource) {
        case DocumentSource.LOCAL:
          await deleteLocalDocument(documentId)
          break

        case DocumentSource.CLOUD:
          await deleteCloudDocument(documentId)
          break

        default:
          throw new Error(
            'Cannot delete document, ' +
              `unknown document source "${documentSource}". ` +
              ' Known sources: "local", "cloud", "url", or "json".'
          )
      }

      removeRecentFile(compoundKey)
    } catch (err) {
      console.error(err)
      notifyError(err)
    }
  }

  async loadFromDisk(file) {
    debug('Loading file from disk...', { file })
    await this.setLoading()

    try {
      const { name, data } = await loadFromDisk(file)
      const document = {
        name: removeFileExtension(name, '.json'),
        content: {
          text: data
        }
      }

      debug('Loaded file from disk', { data, name, document })
      await this.setLoadedDocument(document, null, true)
      debug('loadFromDisk 2 ', this.state.document)
      await this.saveLocally({ silent: true })
    } catch (error) {
      await this.setErroredDocument(error, false)
    }
  }

  saveToDisk(name, formatting) {
    debug('saving document to disk...', { name, formatting })

    // TODO: this is ugly code, refactor this
    let data
    try {
      const content = this.state.document.content
      console.log('this.state.parser', this.state.parser)
      console.time('stringify')
      data = stringifyContent(content, this.state.parser, formatting, this.props.indentation)
      console.timeEnd('stringify')
    } catch (error) {
      if (formatting === Formatting.FORMAT || formatting === Formatting.COMPACT) {
        const message =
          `Failed to ${formatting} the document. ` +
          'Fix the document or select "Indentation: keep as-is", then try to save it again. ' +
          error.toString()
        console.error(message)
        notifyError(message)
      } else {
        console.error(error)
        notifyError(error)
      }

      return
    }

    try {
      const filename = addExtensionIfNeeded(name, '.json')

      saveFileViaAnchor(filename, data)
    } catch (error) {
      console.error(error)
      notifyError(error)
    }
  }

  async loadFromJson(compoundKey) {
    const { documentId } = splitCompoundKey(compoundKey)
    const text = documentId
    const document = _updateDocument({
      content: { text }
    })
    debug('loadFromJson', { document })

    await this.setLoadedDocument(document, compoundKey, true)
  }

  async loadFromUrl(compoundKey) {
    const url = splitCompoundKey(compoundKey).documentId

    debug('Loading file from url...', { compoundKey })
    await this.setLoading()

    try {
      const name = last(url.split('/'))
      const response = await window.fetch(url)
      const data = await response.text()
      const document = {
        loadedFromUrl: url,
        name: removeFileExtension(name, '.json'),
        content: {
          text: data
        }
      }

      debug('Loaded file from url', { data, name })
      this.setLoadedDocument(document, compoundKey, true)
    } catch (error) {
      await this.setErroredDocument(error, false)
    }
  }

  async saveToUrl(url, formatting) {
    debug('Saving document to url...', { url, formatting })

    // TODO: this is ugly code, refactor this
    let data
    try {
      const content = this.state.document.content
      data = stringifyContent(content, this.state.parser, formatting, this.props.indentation)
    } catch (error) {
      if (formatting === Formatting.FORMAT || formatting === Formatting.COMPACT) {
        const message =
          `Failed to ${formatting} the document. ` +
          'Fix the document or select "Indentation: keep as-is", then try to save it again. ' +
          error.toString()
        console.error(message)
        notifyError(message)
      } else {
        console.error(error)
        notifyError(error)
      }

      return
    }

    try {
      await this.updateDocumentProperties({ savedToUrl: url })

      const response = await window.fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: data
      })
      const responseBody = await response.text()

      if (response.status >= 200 && response.status < 300) {
        debug('Document successfully saved to url')
        notifySuccess('Document successfully saved to url.')
      } else {
        notifyError(new Error(response.status + ' ' + response.statusText + ' ' + responseBody))
      }
    } catch (error) {
      console.error(error)
      notifyError(error)
    }
  }

  async setLoading() {
    await this.setStateAsync({
      loading: true,
      loadingError: null,
      localStorageError: null
    })
  }

  async setLoadedDocument(document, compoundKey, silent) {
    const parser = getJSONParser(this.state.parserId, document.content)

    await this.setStateAsync({
      documentSequenceNr: this.state.documentSequenceNr + 1,
      compoundKey,
      document,
      parser,
      loading: false,
      unsavedChanges: false
    })

    debug('setLoadedDocument', {
      hashKey: this.props.hashKey,
      document,
      stateDocument: this.state.document,
      parserId: this.state.parserId,
      parser: parser === JSON ? ParserId.native : ParserId.lossless
    })

    if (isLocalDocument(compoundKey) || isCloudDocument(compoundKey)) {
      addRecentFile(compoundKey, document)
    }

    this.updateHash()

    if (!silent) {
      notifySuccess(`Document "${document.name}" loaded.`)
    }
  }

  async setErroredDocument(error, silent) {
    console.error(error)

    await this.setStateAsync({
      documentSequenceNr: this.state.documentSequenceNr + 1,
      compoundKey: null,
      document: EMPTY_DOCUMENT,
      loading: false,
      unsavedChanges: false,
      loadingError: error
    })

    if (!silent) {
      notifyError(error)
    }
  }

  updateHash() {
    if (this.state.compoundKey) {
      this.hash.setValue(this.props.hashKey, this.state.compoundKey)
    } else {
      this.hash.removeValue(this.props.hashKey)
    }
  }
}

/**
 * Merge properties into the document, and set the `updated` property to the
 * current time.
 * @param {Document} document
 * @param {Object} properties
 * @return {Document}
 */
function _updateDocument(document, properties = {}) {
  return {
    ...document,
    ...properties,
    updated: isoDateNow()
  }
}

/**
 * Helper function to load a file from disk using the HTML5 FileReader API.
 * @param {File} file
 * @return {Promise<{name, data}>}
 */
async function loadFromDisk(file) {
  return new Promise((resolve) => {
    const reader = new window.FileReader()
    reader.onload = function (event) {
      const data = event.target.result
      const name = file.name
      resolve({ name, data })
    }

    reader.readAsText(file)
  })
}

// TODO: rewrite to static field on top of the class as soon as that is officially supported
DocumentProvider.propTypes = {
  hashKey: PropTypes.string.isRequired,
  children: PropTypes.func.isRequired,
  indentation: PropTypes.number.isRequired,
  loadDefaultDocumentOnFirstUse: PropTypes.bool
}

// TODO: cleanup legacy stuff some day
function loadLegacyOrDefault() {
  const legacyData = loadFromLocalStorage('data')
  return legacyData !== undefined ? { content: { json: legacyData } } : DEFAULT_DOCUMENT
}
