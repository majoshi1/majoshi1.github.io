import classnames from 'classnames'
import React, { PureComponent } from 'react'
import './Ads.scss'
import { PLAYWIRE_SMALL_ADS_THRESHOLD } from './constants'

export default class Ads extends PureComponent {
  constructor(props) {
    super(props)

    const { className, dataPwDesk, id } = getAdsSize()

    this.state = {
      className,
      dataPwDesk,
      id
    }
  }

  componentDidMount() {
    // we use a timeout, so we don't block the application whilst loading the script and ads:
    // we want to keep the LCP as fast as possible
    setTimeout(() => {
      try {
        const id = this.state.id
        window.ramp.que.push(function () {
          window.ramp.addTag(id)
        })

        const script = document.createElement('script')
        script.type = 'text/javascript'
        script.src = '//cdn.intergient.com/ramp_core.js'
        document.body.appendChild(script)
      } catch (err) {
        console.error(err)
      }
    })
  }

  render() {
    return (
      <div className={classnames('ads', this.state.className)}>
        <div data-pw-desk={this.state.dataPwDesk} id={this.state.id} />
        {/* Note: the JavaScript code is moved into componentDitMount */}
      </div>
    )
  }
}

export function getAdsSize() {
  return window.innerWidth > PLAYWIRE_SMALL_ADS_THRESHOLD
    ? {
        isLarge: true,
        className: 'large-skyscraper',
        dataPwDesk: 'sky_btf',
        id: 'pwDeskSkyBtf'
      }
    : {
        isLarge: false,
        className: 'wide-skyscraper',
        dataPwDesk: 'sky_atf',
        id: 'pwDeskSkyAtf'
      }
}
