import { createError } from './utils/errorUtils'
import { toSafeDocument } from './utils/documentUtils'

const BACKEND_URL = 'https://jsoneditoronline.herokuapp.com/v1/docs'

/**
 * Get an existing document
 * @param id
 * @return {Promise<Document>}
 */
export async function loadCloudDocument(id) {
  const response = await window.fetch(`${BACKEND_URL}/${id}`, {
    method: 'GET'
  })

  if (response.status < 200 || response.status >= 300) {
    const message = await response.text()

    throw createError({
      message: `Failed to load document with id "${id}". ${message}`,
      reasons: [
        'Did you or someone else delete this cloud document?',
        'Is the id of the document correct or is there a typo?'
      ]
    })
  }

  return migrateDocumentToV2(await response.json())
}

/**
 * Get JSON from an url
 * @param {string} url
 * @return {Promise<JSON>}
 */
export async function loadUrl(url) {
  // TODO: the following check is a workaround for useSchema which is always calling loadUrl also when no SchemaUrl is defined
  if (!url) {
    return null
  }

  const response = await window.fetch(url, {
    method: 'GET'
  })

  if (response.status < 200 || response.status >= 300) {
    const message = await response.text()
    throw Error(`Failed to load url "${url}". ${message}`)
  }

  return response.json()
}

/**
 * Update an existing document
 * @param {Document} document
 * @param {JSONParser} parser
 * @param {number | string} indentation
 * @return {Promise<{id: string}>}
 */
export async function saveCloudDocument(document, parser, indentation) {
  const id = document._id

  const response = await window.fetch(`${BACKEND_URL}/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(migrateDocumentToV1(toSafeDocument(document, parser, indentation)))
  })

  if (response.status < 200 || response.status >= 300) {
    const message = await response.text()
    throw Error(`Failed to save document with id "${id}". ${message}`)
  }

  // TODO: the PUT operation returns the complete document. That's not needed

  return { id }
}

/**
 * Insert a new document
 * @param {Document} document
 * @param {JSONParser} parser
 * @param {number | string} indentation
 * @return {Promise<{id: string}>}
 */
export async function createCloudDocument(document, parser, indentation) {
  const response = await window.fetch(`${BACKEND_URL}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(migrateDocumentToV1(toSafeDocument(document, parser, indentation)))
  })

  if (response.status < 200 || response.status >= 300) {
    const message = await response.text()
    throw Error(`Failed to save document. ${message}`)
  }

  return response.json()
}

/**
 * Delete a document
 * @param {string} documentId
 * @return {Promise<any>}
 */
export async function deleteCloudDocument(documentId) {
  const response = await window.fetch(`${BACKEND_URL}/${documentId}`, {
    method: 'DELETE'
  })

  if (response.status < 200 || response.status >= 300) {
    const message = await response.text()
    throw Error(`Failed to delete document. ${message}`)
  }

  return response.json()
}

/**
 * Migrate the document format with `.data` to `.content`
 * @param {Document} document
 * @retunrs {Document} document
 */
function migrateDocumentToV2(document) {
  const migratedDocument = { ...document }

  if (typeof migratedDocument.data === 'string') {
    if (typeof migratedDocument.content === 'undefined') {
      migratedDocument.content = {
        text: migratedDocument.data
      }
    }

    delete migratedDocument.data
  }

  return migratedDocument
}

/**
 * Migrate the document format with `.content` to `.data`
 * @param {Document} document
 * @retunrs {Document} document
 */
function migrateDocumentToV1(document) {
  const migratedDocument = { ...document }

  if (typeof migratedDocument.content === 'object') {
    if (typeof migratedDocument.data === 'undefined') {
      const content = migratedDocument.content
      migratedDocument.data = content.text ? content.text : JSON.stringify(content.json)
    }
    delete migratedDocument.content
  }

  return migratedDocument
}

// TODO: backward compatible
