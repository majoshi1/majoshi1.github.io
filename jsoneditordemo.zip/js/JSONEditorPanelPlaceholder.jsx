import './JSONEditorPanelPlaceholder.scss'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCircleNotch } from '@fortawesome/free-solid-svg-icons'

export default function JSONEditorPanelPlaceholder({ mode }) {
  return (
    <div className="panel placeholder">
      <div className="panel-menu"></div>
      <div className="panel-contents">
        <div className="jsoneditor-react-container">
          <div className="jse-main">
            <div className="jse-text-mode">
              <div className="jse-menu"></div>
              {mode === 'tree' && (
                <>
                  <div className="jse-navigation-bar"></div>
                </>
              )}
              <div className="jse-contents">
                {mode === 'text' && (
                  <>
                    <div className="placeholder-gutter"></div>
                  </>
                )}
                <div className="placeholder-contents">
                  <div className="placeholder-loading">
                    <FontAwesomeIcon icon={faCircleNotch} spin fixedWidth /> loading...
                  </div>
                </div>
              </div>
              {mode === 'text' && <div className="jse-status-bar"></div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
