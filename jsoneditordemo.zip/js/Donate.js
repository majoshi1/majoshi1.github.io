import './Donate.scss'

export default function Donate() {
  // paypal donate button
  return (
    <div className="donate">
      <div className="donate-info">Enjoying this free editor? Please support me!</div>
      <div className="donate-button">
        <form action="https://www.paypal.com/donate" method="post" target="_top">
          <input type="hidden" name="hosted_button_id" value="A4EB3ZTB6236C" />
          <input
            type="image"
            src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif"
            name="submit"
            title="PayPal - The safer, easier way to pay online!"
            alt="Donate with PayPal button"
          />
          <img
            alt=""
            border="0"
            src="https://www.paypal.com/en_NL/i/scr/pixel.gif"
            width="1"
            height="1"
          />
        </form>
      </div>
    </div>
  )
}
