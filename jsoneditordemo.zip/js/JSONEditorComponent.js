import createDebug from 'debug'
import { isEqual } from 'lodash'
import memoizeOne from 'memoize-one'
import React, { PureComponent } from 'react'
import {
  createAjvValidator,
  jmespathQueryLanguage,
  JSONEditor,
  lodashQueryLanguage,
  renderJSONSchemaEnum,
  renderValue
} from 'vanilla-jsoneditor'
import './JSONEditorComponent.scss'
import { notifyError } from './utils/modalUtils.js'
import classnames from 'classnames'

const debug = createDebug('jsoneditoronline:JSONEditorComponent')

const queryLanguages = [lodashQueryLanguage, jmespathQueryLanguage]

// TODO: rewrite to function component and hooks
export default class JSONEditorComponent extends PureComponent {
  // helper function to memoize a created Ajv validator
  memoizeValidator = memoizeOne(function createValidator(schema, schemaDefinitions) {
    if (schema) {
      try {
        debug('createAjvValidator', { schema, schemaDefinitions })
        return createAjvValidator({ schema, schemaDefinitions })
      } catch (err) {
        debug('failed to compile validator:', err.toString())

        return () => [{ path: [], message: err.toString() }]
      }
    } else {
      return undefined
    }
  }, isEqual)

  memoizeOnRenderValue = memoizeOne(function (schema, schemaDefinitions) {
    if (schema) {
      // enable rendering a select box for enums
      return function onRenderValue(props) {
        return renderJSONSchemaEnum(props, schema, schemaDefinitions) || renderValue(props)
      }
    } else {
      return renderValue
    }
  })

  componentDidMount() {
    debug('componentDidMount')

    this.jsoneditor = new JSONEditor({
      target: this.container,
      props: {
        onError: (err) => {
          console.error(err)
          notifyError(
            <div className="parse-error">
              <code>{err.toString()}</code>
            </div>
          )
        },
        validator: this.memoizeValidator(this.props.schema, this.props.schemaDefinitions),
        onRenderValue: this.memoizeOnRenderValue(this.props.schema, this.props.schemaDefinitions),
        queryLanguages,
        ...this.props
      }
    })

    if (this.props.onJsonEditorRef) {
      this.props.onJsonEditorRef(this.jsoneditor)
    }

    // expose the editor on window for debugging or hacking purposes
    if (this.props.id) {
      if (!window.jsoneditors) {
        window.jsoneditors = {}
      }
      window.jsoneditors[this.props.id] = this.jsoneditor
    }
  }

  componentDidUpdate(prevProps) {
    this.jsoneditor.updateProps(this.props)

    if (
      this.props.schema !== prevProps.schema ||
      this.props.schemaDefinitions !== prevProps.schemaDefinitions
    ) {
      this.jsoneditor.updateProps({
        validator: this.memoizeValidator(this.props.schema, this.props.schemaDefinitions),
        onRenderValue: this.memoizeOnRenderValue(this.props.schema, this.props.schemaDefinitions)
      })
    }
  }

  componentWillUnmount() {
    debug('componentWillUnmount')

    if (this.jsoneditor) {
      this.jsoneditor.destroy()
      this.jsoneditor = null
      this.schema = null
      this.schemaDefinitions = null
    }
  }

  render() {
    return (
      <div
        className={classnames('jsoneditor-react-container', this.props.className, {
          'read-only': this.props.readOnly
        })}
        ref={(elem) => {
          this.container = elem
        }}
      />
    )
  }
}
