import './DidYouKnow.scss'
import { faLightbulb } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React from 'react'

export default function DidYouKnow() {
  return (
    <div className="did-you-know">
      <div className="did-you-know-info">
        <FontAwesomeIcon icon={faLightbulb} /> Did you know JSON Editor Online now has a table mode?
        <br />
        <a
          target="_blank"
          rel="opener noreferrer"
          href="https://jsoneditoronline.org/docs/index.html#table-mode"
        >
          Read more...
        </a>
      </div>
    </div>
  )
}
