import { del, get, keys, set } from 'idb-keyval'
import { loadFromLocalStorage, saveToLocalStorage } from './localStorageUtils'
import { toSafeDocument } from './documentUtils'

const NEW_DOCUMENT_SEQUENCE_KEY = 'newDocumentSequenceNumber'

const PRIVATE_MODE_MESSAGE = 'Are you running in private mode or is the browser history disabled?'

export async function saveLocalDocument(key, document, parser, indentation) {
  try {
    return await set(key, toSafeDocument(document, parser, indentation))
  } catch (err) {
    console.error(err)
    throw isInvalidStateError(err)
      ? new Error('Failed to save document in local database. ' + PRIVATE_MODE_MESSAGE)
      : err
  }
}

export async function loadLocalDocument(key) {
  try {
    return await get(key)
  } catch (err) {
    console.error(err)
    throw isInvalidStateError(err)
      ? new Error('Failed to load document from local database. ' + PRIVATE_MODE_MESSAGE)
      : err
  }
}

export async function deleteLocalDocument(key) {
  console.log('deleteLocalDocument', key)
  try {
    return await del(key)
  } catch (err) {
    console.error(err)
    throw isInvalidStateError(err)
      ? new Error('Failed to delete document from local database. ' + PRIVATE_MODE_MESSAGE)
      : err
  }
}

/**
 * Create a document name like "New document 3"
 * @return {Promise<string>}
 */
export async function createNewDocumentName() {
  try {
    let count = loadFromLocalStorage(NEW_DOCUMENT_SEQUENCE_KEY)

    // fallback mechanism for when local storage key is gone:
    // go through the database to find the highest new document number
    if (count === undefined) {
      count = 0
      const allKeys = await keys()
      const newDocumentRegex = /^New document (\d+)$/

      for (const key of allKeys) {
        const document = await get(key)
        const match = newDocumentRegex.exec(document.name)
        if (match) {
          const number = parseInt(match[1])
          if (number > count) {
            count = number
          }
        }
      }
    }

    const newCount = count + 1
    saveToLocalStorage(NEW_DOCUMENT_SEQUENCE_KEY, newCount)

    return `New document ${newCount}`
  } catch (err) {
    // this function is used when saving a new document, hence the message about "failed to save"
    console.error(err)
    throw isInvalidStateError(err)
      ? new Error('Failed to save document in local database. ' + PRIVATE_MODE_MESSAGE)
      : err
  }
}

function isInvalidStateError(err) {
  return (
    err &&
    err.name === 'InvalidStateError' &&
    err.message === 'A mutation operation was attempted on a database that did not allow mutations.'
  )
}
