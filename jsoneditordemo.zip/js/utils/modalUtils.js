import notify from '../modal/notify'

const NOTIFICATION_TIMEOUT_SUCCESS = 1000 // ms
const NOTIFICATION_TIMEOUT_ERROR = 60000 // ms

export function notifyBusy(text) {
  return notify({
    text
  })
}

export function notifySuccess(text) {
  return notify({
    text,
    timeout: NOTIFICATION_TIMEOUT_SUCCESS
  })
}

export function notifyError(error) {
  return notify({
    text: error && typeof error.message === 'string' ? error.toString() : error,
    className: 'error',
    timeout: NOTIFICATION_TIMEOUT_ERROR,
    closable: true
  })
}
