/**
 * Add file extension to file name unless the filename already ends with
 * the extension.
 * @param {string} filename
 * @param {string} extension  For example ".json"
 * @return {string}
 */
export function addExtensionIfNeeded(filename, extension) {
  if (filename.toLowerCase().endsWith(extension.toLowerCase())) {
    return filename
  }

  return filename + extension
}

/**
 * Remove the extension from a file name if present.
 * @param {string} filename
 * @param {string} extension   For example ".json"
 * @return {string}
 */
export function removeFileExtension(filename, extension) {
  if (filename.toLowerCase().endsWith(extension.toLowerCase())) {
    return filename.substring(0, filename.length - extension.length)
  }

  return filename
}

/**
 * Return a human readable document size
 * For example formatSize(7570718) outputs '7.6 MB'
 * @param {number} size
 * @return {string} Returns a human readable size
 */
export function formatSize(size) {
  if (size < 900) {
    return size.toFixed() + ' B'
  }

  const KB = size / 1000
  if (KB < 900) {
    return KB.toFixed(1) + ' KB'
  }

  const MB = KB / 1000
  if (MB < 900) {
    return MB.toFixed(1) + ' MB'
  }

  const GB = MB / 1000
  if (GB < 900) {
    return GB.toFixed(1) + ' GB'
  }

  const TB = GB / 1000
  return TB.toFixed(1) + ' TB'
}

/**
 * Save a file to disk using an anchor
 * Throws an exception when saving failed
 * @param {string} filename
 * @param {string} data
 */
export function saveFileViaAnchor(filename, data) {
  const a = document.createElement('a')
  try {
    if (typeof window.Blob === 'undefined') {
      throw new Error("Failed to save file to disk. Your browser doesn't support Blob.")
    }
    if (a.download === undefined) {
      throw new Error("Failed to save file to disk. Your browser doesn't support HTML5 a.download.")
    }

    const blob = new window.Blob([data], { type: 'application/json;charset=utf-8' })

    // save file directly using a data URL
    a.style.display = 'none'
    a.rel = 'noopener'
    a.href = URL.createObjectURL(blob)
    a.download = filename

    // attach the element to the DOM, invoke a click action
    document.body.appendChild(a)
    a.click()
  } finally {
    // cleanup created blob url and DOM again
    URL.revokeObjectURL(a.href)
    document.body.removeChild(a)
  }
}
