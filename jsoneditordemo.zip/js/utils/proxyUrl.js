import { PROXY_URL_BASE } from '../constants'

export function toProxyUrl(url) {
  return PROXY_URL_BASE + encodeURIComponent(url)
}

export function isProxyUrl(proxyUrl) {
  return typeof proxyUrl === 'string' && proxyUrl.startsWith(PROXY_URL_BASE)
}

export function fromProxyUrl(proxyUrl) {
  return isProxyUrl(proxyUrl)
    ? decodeURIComponent(proxyUrl.substring(PROXY_URL_BASE.length))
    : proxyUrl
}
