export const MAX_LOCALSTORAGE_SIZE = 1000 * 1000 // 1 MB

/**
 * Helper function to load and deserialize a key/value in the browsers local storage.
 * The function will return undefined when deserializing a stored key failed
 * @param {string} key
 * @param {*} [defaultValue=undefined] Optional default value to be returned
 *                                     When key was not found in local storage
 * @return {*} value
 */
export function loadFromLocalStorage(key, defaultValue) {
  try {
    const value = window.localStorage[key]

    return value !== undefined ? JSON.parse(value) : defaultValue
  } catch (err) {
    console.error('error in function loadProperty  ' + err.message)
    return defaultValue
  }
}

/**
 * Helper function to serialize and store a key/value in the browsers local storage
 * @param {string} key
 * @param {*} value
 * @return {{
 *   success: boolean,
 *   size: number,
 *   maxSize: number,
 *   error: string | null
 * }} result
 */
export function saveToLocalStorage(key, value) {
  const stringifiedValue = JSON.stringify(value)
  const size = stringifiedValue.length

  try {
    if (size <= MAX_LOCALSTORAGE_SIZE) {
      window.localStorage[key] = stringifiedValue

      return {
        success: true,
        error: null,
        size,
        maxSize: MAX_LOCALSTORAGE_SIZE
      }
    } else {
      return {
        success: false,
        error: 'Error: Value too large to store in local storage',
        size,
        maxSize: MAX_LOCALSTORAGE_SIZE
      }
    }
  } catch (err) {
    console.error('error in function saveProperty  ' + err.message)

    return {
      success: false,
      error: err.toString(),
      size,
      maxSize: MAX_LOCALSTORAGE_SIZE
    }
  }
}

/**
 * Remove a key from local storage (if it exists)
 * @param {string} key
 */
export function removeFromLocalStorage(key) {
  try {
    delete window.localStorage[key]
  } catch (err) {
    console.error('error in function removeProperty  ' + err.message)
  }
}
