import { Parser } from 'json2csv'
import { isSafeNumber, JSONValue } from 'lossless-json'
import { flattenObject } from './objectUtils'

/**
 * @param {JSON} json
 * @param {{header: boolean, flatten: boolean}} options
 * @returns {string}
 */
export function jsonToCsv(json: JSONValue, options: { header: boolean; flatten: boolean }): string {
  const header = typeof options.header === 'boolean' ? options.header : true

  if (Array.isArray(json)) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    const processedJson = options.flatten ? json.map((item) => flattenObject(item)) : json
    return new Parser({ header }).parse(processedJson)
  } else {
    // object or primitive
    return (
      new Parser({ header })
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        .parse(options.flatten ? flattenObject(json) : json)
    )
  }
}

export function findUnsafeNumber(text: string, truncateCharacters = Infinity): string | undefined {
  const textTruncated = text.substring(0, truncateCharacters)
  const matches = textTruncated.match(JSON_NUMBER_REGEX)
  if (!matches) {
    return undefined
  }

  // FIXME: if a value is found, verify whether it is not a value inside a string.
  //  to check: a number is surrounded by optional whitespace, and then [  or , before, and , or ] or } after

  return matches.find((value: string) => !isSafeNumber(value)) || undefined
}

export function containsUnsafeNumbers(text: string, truncateCharacters = Infinity): boolean {
  return findUnsafeNumber(text, truncateCharacters) !== undefined
}

const JSON_NUMBER_REGEX = /-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/g
