/**
 * @class Hash
 * This class contains methods to manipulate the hash of the web page
 */
import { fromPairs, isEmpty, toPairs } from 'lodash'

export function createHash() {
  function getQuery() {
    return parseHash(window.location.hash.substring(1))
  }

  function setQuery(query) {
    const hash = stringifyHash(query)
    window.location.hash = hash.length ? '#' + hash : ''
  }

  function setValue(key, value) {
    const query = getQuery()
    const changed = query[key] !== value
    if (changed) {
      setQuery({
        ...query,
        [key]: value
      })
    }
  }

  function getValue(key) {
    const query = getQuery()
    return query[key]
  }

  function removeValue(key) {
    const query = getQuery()
    if (query[key]) {
      delete query[key]
      setQuery(query)
    }
  }

  /** @type {Array.<{key: string, callback: function}>} */
  const listeners = []
  let prevQuery = getQuery()

  function handleHashChange() {
    const query = getQuery()
    listeners.forEach(({ key, callback }) => {
      const changed = query[key] !== prevQuery[key]
      if (changed) {
        callback(query[key])
      }
    })

    prevQuery = query
  }

  function onChange(key, callback) {
    listeners.push({ key, callback })
  }

  window.addEventListener('hashchange', handleHashChange)

  function destroy() {
    window.removeEventListener('hashchange', handleHashChange)
  }

  return {
    getValue,
    setValue,
    onChange,
    removeValue,
    destroy
  }
}

export function parseHash(hash) {
  const pairs = hash
    .split('&')
    .filter((pair) => !isEmpty(pair))
    .map((pair) => {
      return pair.split('=').map(decodeURIComponent)
    })

  return fromPairs(pairs)
}

export function stringifyHash(parameters) {
  return toPairs(parameters)
    .map((pair) => pair.map(encodeURIComponent).join('='))
    .join('&')
}
