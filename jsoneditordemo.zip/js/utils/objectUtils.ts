import { isObjectOrArray } from 'svelte-jsoneditor/utils/typeUtils'

/**
 * Flatten nested properties of an object
 * Source: https://stackoverflow.com/a/56253298/1262753
 * @param {Object} object
 * @param {string} [separator='_']
 * @returns {Object}
 */
export function flattenObject(object: { [key: string]: unknown }, separator = '_') {
  const flat: { [key: string]: unknown } = {}

  function recurse(object: { [key: string]: unknown }, parentPath: string) {
    for (const key in object) {
      const path = parentPath ? parentPath + separator + key : key

      if (isObjectOrArray(object[key])) {
        recurse(object[key] as { [key: string]: unknown }, path)
      } else {
        flat[path] = object[key]
      }
    }
  }

  recurse(object, '')

  return flat
}
