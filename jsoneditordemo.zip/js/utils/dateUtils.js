import { format, parseISO } from 'date-fns'

/**
 * @return {string}
 */
export function isoDateNow() {
  return new Date().toISOString()
}

/**
 * @param isoDate
 * @return {string} returns the formatted date
 */
export function formatDate(isoDate) {
  return format(parseISO(isoDate), 'yyyy-MM-dd HH:mm')
}

/**
 * @param {number} delay A number in milliseconds
 */
export function sleep(delay) {
  return new Promise((resolve) => setTimeout(resolve, delay))
}
