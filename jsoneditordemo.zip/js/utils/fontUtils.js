/**
 * @param {string} fontSize
 * @return {boolean}
 */
export function isValidFontSize(fontSize) {
  return fontSizeRegex.test(fontSize)
}

// match a string like '14px' or '12pt'
const fontSizeRegex = /^\d{2}(px|pt)$/

/**
 * @param {string} fontSize
 * @return {string}
 */
export function normalizeFontSize(fontSize) {
  return fontSize
    .replaceAll(/ /g, '') // remove all white spaces
    .replace(/^\d+$/, (match) => match + 'px') // add a suffix "px" when only a number is entered
    .toLowerCase()
}
