import { parse, stringify } from 'lossless-json'
import type { Content, JSONParser } from 'svelte-jsoneditor'
import { isLargeContent } from 'svelte-jsoneditor'
import { LARGE_DOCUMENT_SIZE } from '../constants'
import { ParserId } from '../enums'

const LosslessJSONParser = { parse, stringify } as unknown as JSONParser

const defaultOptions = { largeDocumentSize: LARGE_DOCUMENT_SIZE }

export function getJSONParser(
  parserId: ParserId,
  content: Content,
  options: { largeDocumentSize: number } = defaultOptions
): JSONParser {
  switch (parserId) {
    case ParserId.lossless:
      return LosslessJSONParser

    case ParserId.auto:
      if (!isLargeContent(content, options.largeDocumentSize)) {
        return LosslessJSONParser
      } else {
        // We can also check whether the document containsUnsafeNumbers and if so,
        // choose the LosslessJSONParser too. But that will not be 100% safe too,
        // since we can only do a sample (scanning the full document is too slow)
        // So, right now, we keep things simple. We will sample for unsafe contents
        // anyway, and show a warning message instead.
        return JSON
      }

    default:
      // 'native'
      return JSON
  }
}
