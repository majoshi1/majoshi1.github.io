import { isEqual } from 'lodash'

/**
 * Memoize the arguments of the last function call.
 * If the function is called again with the same arguments,
 * the last result returned. If the arguments differ,
 * function is called again.
 * @param {function} fn
 * @return {function}
 */
export function memoizeLastArguments(fn) {
  let lastArgs
  let lastResult

  return (...args) => {
    if (isEqual(args, lastArgs)) {
      return lastResult
    }

    lastArgs = args
    lastResult = fn(...args)

    return lastResult
  }
}
