import { isEqualParser, isTextContent } from 'svelte-jsoneditor' // do not use vanilla-jsoneditor to allow code splitting
import { Formatting } from '../constants.js'
import { loadCloudDocument } from '../rest'
import { loadLocalDocument } from './indexedDbUtils'

/**
 * Return content as JSON
 * @param {Content} content
 * @param {JSON} parser
 * @return {JSON}
 */
export function parseContent(content, parser) {
  return isTextContent(content) ? parser.parse(content.text) : content.json
}

/**
 * Return content as stringified JSON
 * @param {Content} content
 * @param {JSON} parser
 * @param {FormattingOption} [formatting]
 * @param {number} [defaultIndentation]
 * @return {string}
 */
export function stringifyContent(
  content,
  parser,
  formatting = undefined,
  defaultIndentation = undefined
) {
  if (isTextContent(content)) {
    if (formatting === Formatting.FORMAT) {
      return parser.stringify(parser.parse(content.text), null, defaultIndentation)
    } else if (formatting === Formatting.COMPACT) {
      return parser.stringify(parser.parse(content.text))
    } else {
      // KEEP
      return content.text
    }
  } else {
    const indentation = formatting === Formatting.COMPACT ? undefined : defaultIndentation

    return parser.stringify(content.json, null, indentation)
  }
}

/**
 * Return content as JSON
 * @param {Content} content
 * @param {JSONParser} parser
 * @param {number | string} indentation
 * @return {Content}
 */
export function toSafeContent(content, parser, indentation) {
  // TODO: we can make this function smarter:
  //  when we have json contents but there are no unsafe or formatted numbers,
  //  we can convert into native JSON
  //  (i.e. converting to number and then back to string should give the exact equal string)
  return isEqualParser(parser, JSON)
    ? content
    : isTextContent(content)
    ? content
    : {
        text: parser.stringify(content.json, null, indentation)
      }
}

/**
 @param {Document} document
 * @param {JSONParser} parser
 * @param {number | string} indentation
 * @return {Document}
 */
export function toSafeDocument(document, parser, indentation) {
  return {
    ...document,
    content: toSafeContent(document.content, parser, indentation)
  }
}

/**
 * @param {string} text
 * @param {JSON} parser
 * @param {number} [indentation]
 * @return {string}
 */
export function tryFormat(text, parser, indentation) {
  try {
    return parser.stringify(parser.parse(text), null, indentation)
  } catch (err) {
    return text
  }
}

export function tryFormatContent(content, parser, indentation) {
  try {
    const json = isTextContent(content) ? parser.parse(content.text) : content.json

    return {
      text: parser.stringify(json, null, indentation)
    }
  } catch (err) {
    return content
  }
}

/**
 * @param {Content} content
 * @return {string}
 */
export function getContentsDescription(content) {
  try {
    // we can safely use the native JSON parser here: we only look at the number of items
    const json = parseContent(content, JSON)

    if (Array.isArray(json)) {
      return `Array containing ${json.length} items`
    }

    if (json && typeof json === 'object') {
      return `Object containing ${Object.keys(json).length} properties`
    }

    if (json === null) {
      return 'null'
    }

    return typeof json
  } catch (err) {
    return 'Invalid JSON'
  }
}

/**
 * @param {CompoundKey} compoundKey
 * @return {string | undefined}
 */
export function createSharableUrl(compoundKey) {
  if (isCloudDocument(compoundKey)) {
    const origin = window.location.origin
    return `${origin}/#left=${compoundKey}`
  }

  // TODO: extend with support for json and url source
}

/**
 * @param {CompoundKey} compoundKey
 * @return {boolean}
 */
export function hasDocumentSource(compoundKey) {
  return compoundKey.indexOf('.') !== -1
}

//
/**
 * split documentId like 'local.123' or 'cloud.c6386c2797114630b6cb09f5b50bfaf1'
 * @param {CompoundKey} compoundKey
 * @returns {{documentId: null, documentSource: null} | {documentId: string, documentSource: string}}
 */
export function splitCompoundKey(compoundKey) {
  const indexDot = compoundKey ? compoundKey.indexOf('.') : -1

  if (indexDot === -1) {
    return {
      documentSource: null,
      documentId: null
    }
  }

  return {
    documentSource: compoundKey.substring(0, indexDot),
    documentId: compoundKey.substring(indexDot + 1)
  }
}

/**
 * @param {CompoundKey} compoundKey
 * @return {boolean}
 */
export function isLocalDocument(compoundKey) {
  return compoundKey && compoundKey.startsWith('local.')
}

/**
 * @param {CompoundKey} compoundKey
 * @return {boolean}
 */
export function isCloudDocument(compoundKey) {
  return compoundKey && compoundKey.startsWith('cloud.')
}

/**
 * @param {CompoundKey} compoundKey
 * @return {boolean}
 */
export function isJsonDocument(compoundKey) {
  return compoundKey && compoundKey.startsWith('json.')
}

/**
 * @param {CompoundKey} compoundKey
 * @return {boolean}
 */
export function isUrlDocument(compoundKey) {
  return compoundKey && compoundKey.startsWith('url.')
}

export async function loadDocument(compoundKey) {
  if (!compoundKey) {
    return Promise.resolve(null)
  }

  const { documentId } = splitCompoundKey(compoundKey)
  return isCloudDocument(compoundKey)
    ? loadCloudDocument(documentId)
    : loadLocalDocument(documentId)
}
