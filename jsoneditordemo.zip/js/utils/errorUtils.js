/**
 * Helper function to create an error with reasons
 * @param {string} message
 * @param {string[]} reasons
 * @return {Error}
 */
export function createError({ message, reasons }) {
  const error = new Error(message)
  error.reasons = reasons

  return error
}
