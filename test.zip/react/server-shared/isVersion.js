const isVersion = str => {
  return !!str.trim().match(/^v([0-9]+)(?:\.([0-9]+))?(?:\.([0-9]+))?(-.*)?$/);
};

module.exports = isVersion;
