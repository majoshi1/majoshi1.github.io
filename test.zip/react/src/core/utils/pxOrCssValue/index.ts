/**
 * Convert a number to a string with 'px' suffix or return the string as is.
 */
export default function pxOrCssValue(val: number | string) {
  return typeof val === 'string' ? val : `${val}px`;
}
