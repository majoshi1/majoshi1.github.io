import type { $TSFixMe } from '@readme/iso';

import * as amplitude from '@amplitude/analytics-browser';
import { AMPLITUDE_EVENT, AMPLITUDE_EVENT_PROPERTY } from '@readme/iso/src/amplitude';
import { useCallback, useContext, useEffect, useMemo } from 'react';

import type { ConfigContextValue, ProjectContextValue } from '@core/context';
import { ProjectContext, UserContext, ConfigContext } from '@core/context';
import useUserPermissions from '@core/hooks/useUserPermissions';
import { useSuperHubStore } from '@core/store';

type EventProperties = Record<string, unknown>;

export default function useAmplitude({ configOpts }: { configOpts?: amplitude.Types.DefaultTrackingOptions } = {}) {
  const { project } = useContext(ProjectContext) as ProjectContextValue;
  const user = useContext(UserContext) as $TSFixMe;
  const isSuperHub = useSuperHubStore(s => s.isSuperHub);

  // The shape of user context differs between hub and dash
  const email = user?.user?.email || user?.email;

  const {
    releaseVersion,
    amplitude: { apiKey: amplitudePublicKey, enabled } = {
      apiKey: '',
      enabled: false,
    },
  } = useContext(ConfigContext) as ConfigContextValue;

  const { isAdminUser } = useUserPermissions();

  // Initialize Amplitude's client via our environment public key, the current auth'd user, and any other options
  // DefaultTracking is disabled, because we're not concerned with tracking all page views and other ancillary data
  // This also keeps our usage lower and more explicit
  useEffect(() => {
    if (enabled) amplitude.init(amplitudePublicKey, email, { defaultTracking: false, ...configOpts });
  }, [email, amplitudePublicKey, configOpts, enabled]);

  // Give additional context to current Amplitude client
  // We're currently only tracking project plan + subdomain, but this can easily be ammended
  useEffect(() => {
    if (!enabled) return;
    const { subdomain, plan } = project;

    amplitude.setGroup('plan', plan);
    amplitude.setGroup('subdomain', subdomain);
  }, [enabled, project]);

  // Core data included with every tracking event
  const eventMetaData = useMemo(() => {
    const { metrics } = project;

    return {
      ...(metrics && { metrics: { monthlyPurchaseLimit: metrics.monthlyPurchaseLimit } }),
      isSuperHub,
      permission: isAdminUser ? 'admin' : 'readonly',
      releaseVersion,
    };
  }, [isAdminUser, isSuperHub, project, releaseVersion]);

  // `amplitude.track` wrapper -> consume our core data, along with anything else passed in
  const track = useCallback(
    (event: AMPLITUDE_EVENT, eventProperties?: EventProperties) => {
      return enabled && amplitude.track(event, { ...eventMetaData, ...eventProperties });
    },
    [enabled, eventMetaData],
  );

  // Set user ID for Amplitude client (i.e. in signup flows as it becomes known)
  const setUserID = useCallback((userID: string) => enabled && amplitude.setUserId(userID), [enabled]);

  // Only expose true Amplitude SDK methods if enabled
  if (!enabled) return { setUserID: () => {}, track: () => {} };

  // Expose core methods
  return { setUserID, track };
}

// Export event enums here as well for easy access when importing hook
export { AMPLITUDE_EVENT, AMPLITUDE_EVENT_PROPERTY };
