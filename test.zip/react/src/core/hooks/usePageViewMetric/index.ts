import { useCallback, useEffect, useContext } from 'react';
import { useLocation } from 'react-router-dom';

import { LocalizationContext, ProjectContext, VersionContext } from '@core/context';
import useDebounced from '@core/hooks/useDebounced';
import { useMetricsAPIFetcher } from '@core/hooks/useMetricsAPI';
import { useSuperHubStore } from '@core/store';

const ROUTES_FOR_PAGE_LOAD_EVENT = ['recipes', 'edits', 'suggested-edits'];

const usePageViewMetric = () => {
  const { pathname } = useLocation();

  const { project } = useContext(ProjectContext);
  const language = useContext(LocalizationContext);
  const { version } = useContext(VersionContext);
  const metricsFetch = useMetricsAPIFetcher({ version });

  const [layout] = useSuperHubStore(store => [store.layout]);

  /*
   * Debouncing is necessary for pageview metrics as we sometimes update the path in quick succession automatically.
   * For example when a user click on the reference section they go to `/reference` and then we will then update the
   * path to the match the first operation in the Oas; therefore, the path might become something like `/reference/_get`.
   */
  const requestCb = useCallback(() => {
    const { childrenProjects } = project || {};
    // RM-10752: Don't send pageview metrics for routes exposed while editing in SuperHub
    // Similarly, if we're at the project parent level, don't capture pageviews - there's no route!
    if (layout !== 'default' || childrenProjects?.length) return;

    const payload = {
      requestType: 'pageView',
      path: pathname,
      type: pathname.split('/')[1] || '',
      language,
    };

    if (Object.values(payload).length) {
      // Manually triggering the pageLoad event for weird and/or Angular-powered routes
      if (ROUTES_FOR_PAGE_LOAD_EVENT.includes(payload.type)) {
        const titleMapping = {
          recipes: 'Recipes',
          edits: 'Suggest An Edit',
          'suggested-edits': 'Your Suggested Edits',
        };

        $(window).trigger('pageLoad', {
          opts: { reactApp: 'on' },
          hash: window.location.hash,
          name: payload.type,
          fallback: true,
          meta: {
            // We're monkey patching a title here so it doesn't break the Segment integration
            title: titleMapping[payload.type],
          },
        });
      }

      metricsFetch({
        path: 'create/pageview',
        method: 'POST',
        body: payload,
      });
    }
  }, [project, layout, pathname, language, metricsFetch]);

  const debouncedRequest = useDebounced(requestCb, 200);

  useEffect(() => {
    debouncedRequest();
  }, [debouncedRequest]);

  return pathname;
};

export default usePageViewMetric;
