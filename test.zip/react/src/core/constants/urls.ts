/** URL for Manage Plans page when linking from Hub to Dash */
export const PLAN_UPGRADE_URL = '/dash?to=plans';
