import * as rdmd from '@readme/markdown';

/**
 * Converts markdown to plain text, stripping out any markdown syntax.
 * @example markdownToPlainText('**Hello** _world_') // 'Hello world'
 */
export const markdownToPlainText = (markdown: string) => rdmd.astToPlainText(rdmd.hast(markdown)).trim();
