export enum VoteType {
  DOWN = 'down',
  UP = 'up',
}
