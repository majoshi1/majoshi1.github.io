export const CUSTOM_BLOCK_NAME_EXISTS = 'CUSTOM_BLOCK_NAME_EXISTS';
export const INVALID_CUSTOM_BLOCK_NAME = 'INVALID_CUSTOM_BLOCK_NAME';

// Ensure the name includes at least one alphanumeric character
export const customBlockNameRegex = /^(?=.*[a-zA-Z0-9]).*$/;

export const capitalize = (word: string) => word.charAt(0).toUpperCase() + word.slice(1);

export const addSpacesInBetweenWords = (phrase: string) => phrase.replace(/([a-z])([A-Z])/, '$1 $2');
