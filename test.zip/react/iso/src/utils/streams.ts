export const streamDelimiter = '\n---';
