delete from "user-test".public.user_blocked;
delete from "user-test".public.subscribers;
delete from "user-test".public.user_muted;
delete from "user-test".public.user_follower_requests;
delete from "user-test".public.user_subscriptions;
delete from "user-test".public.users;
