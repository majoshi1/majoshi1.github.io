delete from "lists-test".public.pinned_lists;
delete from "lists-test".public.lists_followers;
delete from "lists-test".public.lists_members;
delete from "lists-test".public.lists;
