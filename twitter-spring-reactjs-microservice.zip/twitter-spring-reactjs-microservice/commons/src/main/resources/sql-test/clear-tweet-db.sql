delete from "tweet-test".public.replies;
delete from "tweet-test".public.quotes;
delete from "tweet-test".public.tweets_images;
delete from "tweet-test".public.tweet_images;
delete from "tweet-test".public.poll_choice_voted;
delete from "tweet-test".public.polls_poll_choices;
delete from "tweet-test".public.tweet_quote;

delete from "tweet-test".public.bookmarks;
delete from "tweet-test".public.liked_tweets;
delete from "tweet-test".public.poll_choices;
delete from "tweet-test".public.retweets;

delete from "tweet-test".public.tweets;
delete from "tweet-test".public.polls;
