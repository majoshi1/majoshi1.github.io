delete from "notification-test".public.notifications;
