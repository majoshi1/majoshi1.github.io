delete from "topic-test".public.topic_not_interested;
delete from "topic-test".public.topic_followers;
delete from "topic-test".public.topics;
