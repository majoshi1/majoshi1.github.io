delete from "chat-test".public.chats_participants;
delete from "chat-test".public.chat_messages;
delete from "chat-test".public.chats;
