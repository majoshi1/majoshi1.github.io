delete from "tag-test".public.tweet_tags;
delete from "tag-test".public.tags;
