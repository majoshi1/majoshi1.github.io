package com.gmail.merikbest2015.enums;

public enum BackgroundColorType {
    DEFAULT, DIM, LIGHTS_OUT
}
