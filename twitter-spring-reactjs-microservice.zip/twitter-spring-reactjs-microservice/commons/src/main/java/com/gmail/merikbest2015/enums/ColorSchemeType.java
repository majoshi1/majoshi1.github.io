package com.gmail.merikbest2015.enums;

public enum ColorSchemeType {
    BLUE, YELLOW, CRIMSON, VIOLET, ORANGE, GREEN
}
