package com.gmail.merikbest2015.enums;

public enum LinkCoverSize {
    SMALL, MEDIUM, LARGE
}
