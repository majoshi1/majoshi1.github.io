package com.gmail.merikbest2015.enums;

public enum NotificationType {
    TWEET, RETWEET, REPLY, LIKE, FOLLOW, LISTS
}
