package com.gmail.merikbest2015.enums;

public enum TopicCategory {
    FASHION_AND_BEAUTY,
    OUTDOORS,
    ARTS_AND_CULTURE,
    ANIMATION_AND_COMICS,
    BUSINESS_AND_FINANCE,
    FOOD,
    TRAVEL,
    ENTERTAINMENT,
    MUSIC,
    GAMING,
    CAREERS,
    SPORTS,
    ONLY_ON_TWITTER
}
