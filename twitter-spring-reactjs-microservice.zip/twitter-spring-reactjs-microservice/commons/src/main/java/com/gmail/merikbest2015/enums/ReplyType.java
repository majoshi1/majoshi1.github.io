package com.gmail.merikbest2015.enums;

public enum ReplyType {
    EVERYONE, FOLLOW, MENTION
}
