package com.gmail.merikbest2015.dto.response.notification;

import lombok.Data;

@Data
public class NotificationListResponse {
    private Long id;
    private String name;
}
