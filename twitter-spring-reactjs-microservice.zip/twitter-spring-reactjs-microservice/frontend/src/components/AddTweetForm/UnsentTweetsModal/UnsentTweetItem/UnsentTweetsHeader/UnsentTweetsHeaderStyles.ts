import {makeStyles} from "@material-ui/core";

export const useUnsentTweetsHeaderStyles = makeStyles((theme) => ({
    outlinedButton: {
        height: 24,
        padding: '0px 12px',
    },
}));
