import {makeStyles, Theme} from "@material-ui/core";

export const useActionIconButtonStyles = makeStyles((theme: Theme) => ({
    icon: {
        display: "inline-block",
    },
}));
